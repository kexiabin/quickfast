// FIX Adapted for STreaming (sm) (FAST Protocol (sm)) 
//
// Copyright (c) 2005-2006, Rapid Addition Ltd (http://www.rapidaddition.com)
// Copyright (c) 2005-2006, Pantor Engineering AB (http://www.pantor.com)
// Copyright (c) 2005-2006, SpryWare LLC (http://www.spryware.com)
// Copyright (c) 2005-2006, FIX Protocol Ltd (http://www.fixprotocol.org)
// All Rights Reserved.
//
// This work is distributed under the W3C� Software License [1] in the
// hope that it will be useful, but WITHOUT ANY WARRANTY; without even the
// implied warranty of MERCHANTABILITY, SATISFACTORY QUALITY or FITNESS 
// FOR A PARTICULAR PURPOSE.
//
// [1] http://www.w3.org/Consortium/Legal/2002/copyright-software-20021231
// [FPL's Intellectual Property details] http://www.fixprotocol.org/ip
// [FAST Protocol details] http://www.fixprotocol.org/fast
// [FAST Protocol credits] http://fixprotocol.org/fastcredits

using System;
using System.IO;
using System.Collections;
using System.Text;
using FAST;

namespace Decoder
{
    class Program
    {
        private const int NO_TEMPLATES = 1;
        private const int NO_SLOTS = 7;

        /// <summary>
        /// Test template identifiers
        /// </summary>
        enum tids
        {
            Base = 0,
        };

        /// <summary>
        /// Test field definitions
        /// </summary>
        enum fields
        {
            TID = 0,
            SeqNum = 1,
            Time = 2,
            Symbol = 3,
            Price = 4,
            Shares = 5,
            Exch = 6,
        };


        static void Main(string[] args)
        {
            uint Tid = 0;
            uint SeqNum = 0;
            uint Time = 0;
            string Symbol = "";
            uint Price = 0;
            uint Shares = 0;
            string Exch = "";

            try
            {
                FileStream Input = new FileStream(args[0], FileMode.Open, FileAccess.Read, FileShare.Read);
                BinaryReader BR = new BinaryReader(Input);
                StreamWriter SW = new StreamWriter(args[1], false);

                CTransferEncoder TransferEncoder = new CTransferEncoder(BR, NO_SLOTS);
                CCODEC Codec = new CCODEC(TransferEncoder, NO_TEMPLATES, NO_SLOTS);

                Codec.AddFieldDef((int)fields.TID, CFieldDef.type.U32, CFieldDef.op.Copy, (int)tids.Base, 0);
                Codec.AddFieldDef((int)fields.SeqNum, CFieldDef.type.U32, CFieldDef.op.Incr, (int)tids.Base, 1);
                Codec.AddFieldDef((int)fields.Time, CFieldDef.type.U32, CFieldDef.op.Copy, (int)tids.Base, 2);
                Codec.AddFieldDef((int)fields.Symbol, CFieldDef.type.String, CFieldDef.op.Copy, (int)tids.Base, 3);
                Codec.AddFieldDef((int)fields.Price, CFieldDef.type.U32, CFieldDef.op.Copy, (int)tids.Base, 4);
                Codec.AddFieldDef((int)fields.Shares, CFieldDef.type.U32, CFieldDef.op.Copy, (int)tids.Base, 5);
                Codec.AddFieldDef((int)fields.Exch, CFieldDef.type.String, CFieldDef.op.Copy, (int)tids.Base, 6);

                while (Codec.DecodeNewMsg((int)fields.TID) > 0)
                {
                    Codec.DecodeU32((int)fields.TID, ref Tid);

                    // SeqNum is first 6 chars in input file, starting at pos 0
                    Codec.DecodeU32((int)fields.SeqNum, ref SeqNum);

                    // Time is next 6 chars in input file, starting at pos 7
                    Codec.DecodeU32((int)fields.Time, ref Time);

                    // Symbol is next 3 chars in input file, starting at pos 14
                    Codec.DecodeString((int)fields.Symbol, ref Symbol);

                    // Price is next 5 chars in input file, starting at pos 18
                    Codec.DecodeU32((int)fields.Price, ref Price);

                    // Shares are next 3 chars in input file, starting at pos 24
                    Codec.DecodeU32((int)fields.Shares, ref Shares);

                    // Exchange is next char in input file, starting at pos 28
                    Codec.DecodeString((int)fields.Exch, ref Exch);

                    // we are done with this message
                    Codec.DecodeEndMsg();
                        
                    SW.WriteLine(SeqNum.ToString("000000") + " " + 
                                        Time.ToString("000000") + " " + 
                                        Symbol + " " + 
                                        Price.ToString("00000") + " " + 
                                        Shares.ToString("000") + " " +
                                        Exch);

                }

                BR.Close();
                SW.Close();
            }
            catch (Exception E)
            {
                System.Console.WriteLine(E.Message);
            }
        }
    }
}
