// FIX Adapted for STreaming (sm) (FAST Protocol (sm)) 
//
// Copyright (c) 2005-2006, Rapid Addition Ltd (http://www.rapidaddition.com)
// Copyright (c) 2005-2006, Pantor Engineering AB (http://www.pantor.com)
// Copyright (c) 2005-2006, SpryWare LLC (http://www.spryware.com)
// Copyright (c) 2005-2006, FIX Protocol Ltd (http://www.fixprotocol.org)
// All Rights Reserved.
//
// This work is distributed under the W3C� Software License [1] in the
// hope that it will be useful, but WITHOUT ANY WARRANTY; without even the
// implied warranty of MERCHANTABILITY, SATISFACTORY QUALITY or FITNESS 
// FOR A PARTICULAR PURPOSE.
//
// [1] http://www.w3.org/Consortium/Legal/2002/copyright-software-20021231
// [FPL's Intellectual Property details] http://www.fixprotocol.org/ip
// [FAST Protocol details] http://www.fixprotocol.org/fast
// [FAST Protocol credits] http://fixprotocol.org/fastcredits

using System;
using System.Collections;
using System.Text;

namespace FAST
{
    /// <summary>
    /// The CFieldDef class holds the field definitions that specify
    /// how a field will be encoded / decoded. This includes the data type,
    /// encoding / decoding operation and presence map slot.
    /// </summary>
    public class CFieldDef
    {
        /// <summary>
        /// Field operator enumeration
        /// </summary>
        public enum op
        {
            /// <summary>
            /// No operation
            /// </summary>
            None = 0,
            /// <summary>
            /// Copy operation
            /// </summary>
            Copy,
            /// <summary>
            /// Incremental operation
            /// </summary>
            Incr,
            /// <summary>
            /// Delta operation
            /// </summary>
            Delta
        };

        /// <summary>
        /// Field data type enmeration
        /// </summary>
        public enum type
        {
            /// <summary>
            /// Null data type
            /// </summary>
            Null = 0,
            /// <summary>
            /// Unsigned 32 bit integer data type
            /// </summary>
            U32,
            /// <summary>
            /// Signed 32 bit integer data type
            /// </summary>
            I32,
            /// <summary>
            /// String data type
            /// </summary>
            String
        };

        /// <summary>
        /// Field indentified
        /// </summary>
        int m_ID;
        /// <summary>
        /// Field encoding operator
        /// </summary>
        op m_OP;
        /// <summary>
        /// Field data type
        /// </summary>
        type m_Type;
        /// <summary>
        /// Field template identifier
        /// </summary>
        int m_TID;
        /// <summary>
        /// Field presence map slot
        /// </summary>
        int m_Slot;

        /// <summary>
        /// Constructor
        /// </summary>
        /// <param name="ID">Field identifier</param>
        /// <param name="Type">Field data type</param>
        /// <param name="OP">Field encoding operator</param>
        /// <param name="TID">Field template id</param>
        /// <param name="Slot">Field presence map slot</param>
        public CFieldDef(int ID, type Type, op OP, int TID, int Slot)
        {
            m_ID = ID;
            m_OP = OP;
            m_Type = Type;
            m_TID = TID;
            m_Slot = Slot;
        }

        /// <summary>
        /// Gets the field identifier
        /// </summary>
        int ID
        {
            get {return m_ID;}
        }

        /// <summary>
        /// Gets the field encoding operator
        /// </summary>
        public op OP
        {
            get {return m_OP;}
        }

        /// <summary>
        /// Gets the field data type
        /// </summary>
        public type Type
        {
            get {return m_Type;}
        }

        /// <summary>
        /// Gets the field template id
        /// </summary>
        public int TID
        {
            get {return m_TID;}
        }

        /// <summary>
        /// Gets the field presence map slot
        /// </summary>
        public int Slot
        {
            get {return m_Slot;}
        }
    }
}
