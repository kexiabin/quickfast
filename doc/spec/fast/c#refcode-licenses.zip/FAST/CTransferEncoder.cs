// FIX Adapted for STreaming (sm) (FAST Protocol (sm)) 
//
// Copyright (c) 2005-2006, Rapid Addition Ltd (http://www.rapidaddition.com)
// Copyright (c) 2005-2006, Pantor Engineering AB (http://www.pantor.com)
// Copyright (c) 2005-2006, SpryWare LLC (http://www.spryware.com)
// Copyright (c) 2005-2006, FIX Protocol Ltd (http://www.fixprotocol.org)
// All Rights Reserved.
//
// This work is distributed under the W3C� Software License [1] in the
// hope that it will be useful, but WITHOUT ANY WARRANTY; without even the
// implied warranty of MERCHANTABILITY, SATISFACTORY QUALITY or FITNESS 
// FOR A PARTICULAR PURPOSE.
//
// [1] http://www.w3.org/Consortium/Legal/2002/copyright-software-20021231
// [FPL's Intellectual Property details] http://www.fixprotocol.org/ip
// [FAST Protocol details] http://www.fixprotocol.org/fast
// [FAST Protocol credits] http://fixprotocol.org/fastcredits

using System;
using System.IO;
using System.Collections;
using System.Text;

namespace FAST
{
    /// <summary>
    /// The CSERDES class is the base class for serdes (serialisers / deserialisers).
    /// </summary>
    public class CTransferEncoder
    {
        /// <summary>
        /// Sign mask for signed 32 bit integers
        /// </summary>
        private const int SIGN_MASK_I32 = 0x40;
        /// <summary>
        /// Sign mask for unsigned 32 bit integers
        /// </summary>
        private const int SIGN_MASK_U32 = 0x00;
        /// <summary>
        /// Message buffer size
        /// </summary>
        private const int MSG_BUFFER_SIZE = 1024;
        /// <summary>
        /// Parser bugger size
        /// </summary>
        private const int PARSE_BUFFER_SIZE = 1024;

        /// <summary>
        /// Presence map
        /// </summary>
        private CPMAP m_PMAP;
        /// <summary>
        /// Message buffer, used when serialising
        /// </summary>
        private byte[] m_MsgBuffer = new byte[MSG_BUFFER_SIZE];
        /// <summary>
        /// Current utlised message buffer size
        /// </summary>
        private int m_MsgSize;
        /// <summary>
        /// Parse buffer, used when deserialising
        /// </summary>
        private byte[] m_ParseBuffer = new byte[PARSE_BUFFER_SIZE];
        /// <summary>
        /// Bit mask
        /// </summary>
        private uint[] m_BitMask = new uint[] {64, 32, 16, 8, 4, 2, 1, 0};
        /// <summary>
        /// Binary writer stream used during serialisation
        /// </summary>
        private BinaryWriter m_BW;
        /// <summary>
        /// Binary reader stream used during deserialisation
        /// </summary>
        private BinaryReader m_BR;

        /// <summary>
        /// Constructor for serialisation process
        /// </summary>
        /// <param name="BW">Binary writer stream</param>
        /// <param name="NoSlots">Number of slots required in presence map</param>
        public CTransferEncoder(BinaryWriter BW, int NoSlots)
        {
            m_BW = BW;
            m_PMAP = new CPMAP(NoSlots);
        }

        /// <summary>
        /// Constructor for deserialisation process
        /// </summary>
        /// <param name="BR">Binary reader stream</param>
        /// <param name="NoSlots">Number of slots required in presence map</param>
        public CTransferEncoder(BinaryReader BR, int NoSlots)
        {
            m_BR = BR;
            m_PMAP = new CPMAP(NoSlots);
        }

        /// <summary>
        /// Align an integer to specified number of bits
        /// </summary>
        /// <param name="X">Value to align</param>
        /// <param name="Size">Number of bits to align to</param>
        /// <returns>Number of bytes required</returns>
        private uint Align(uint X, uint Size)
        {
            return (X + Size - 1) / Size;
        }

        /// <summary>
        /// Align an integer to specified 7 bits
        /// </summary>
        /// <param name="X">Value to align</param>
        /// <returns>Number of bytes required</returns>
        private uint Align7(uint X) 
        { 
            return Align(X, 7); 
        }

        /// <summary>
        /// Writes the pmap to the output stream (serialisation)
        /// </summary>
        private void FlushPMAP()
        {
            int Bytes = (int) Align7((uint) (m_PMAP.Size)); // get map size in bytes

            // pack slots from map->bits (seven at a time) into
            // data to form a STOP bit coded field.

            for (int Idx = 0, Offset = 0 ; Idx < Bytes ; Idx ++, Offset += 7)
            {
                byte Temp = 0;

                for (int SubIdx = 0 ; SubIdx < 7 ; SubIdx ++) // pack 7 slot into temp
                {
                    if (m_PMAP.Bits[SubIdx + Offset])
                    {
                        Temp |= (byte) m_BitMask[SubIdx];
                    }
                }

                if (Idx == Bytes - 1)
                {
                    m_BW.Write((byte)(Temp | 0x80)); // Set the STOP bit
                }
                else
                {
                    m_BW.Write((byte)Temp);
                }
            }
        }

        /// <summary>
        /// Writes the message to the output stream (serialisation)
        /// </summary>
        private void FlushMessage()
        {
            m_BW.Write(m_MsgBuffer, 0, m_MsgSize);
        }

        /// <summary>
        /// Append a byte to the message buffer
        /// </summary>
        /// <param name="Value">Byte value</param>
        /// <returns>Number of bytes appended</returns>
        private uint EmitByte(byte Value)
        {
            m_MsgBuffer[m_MsgSize++] = Value;
            return 1;
        }

        /// <summary>
        /// Calculates number of encoded bytes required for an unsigned 32 bit value
        /// </summary>
        /// <param name="Value">Value</param>
        /// <returns>Number of bytes</returns>
        private int U32ToSize(uint Value)
        {
            if (Value < 0x00000080)
            {
                return 1; // 128
            }

            if (Value < 0x00004000)
            {
                return 2; // 16384
            }

            if (Value < 0x00200000)
            {
                return 3; // 2097152
            }

            if (Value < 0x10000000)
            {
                return 4; // 268435456
            }

            return 5;
        }

        /// <summary>
        /// Calculates number of encoded bytes required for a signed 32 bit value
        /// </summary>
        /// <param name="Data">Value to calculate size</param>
        /// <returns>Number of bytes</returns>
        private int I32ToSize(int Data)
        {
            if (Data < 0)
            {
                if (Data >= -64) // 0xffffffc0
                {
                    return 1;
                }

                if (Data >= -8192) // 0xffffe000
                {
                    return 2;
                }

                if (Data >= -1048576) // 0xfff00000
                {
                    return 3;
                }

                if (Data >= -124317728) // 0xf8000000
                {
                    return 4;
                }
            }
            else
            {
                if (Data < 0x00000040)
                {
                    return 1; // 64
                }

                if (Data < 0x00002000)
                {
                    return 2; // 8192
                }

                if (Data < 0x00100000)
                {
                    return 3; // 1048576
                }

                if (Data < 0x08000000)
                {
                    return 4; // 134217728
                }
            }

            return 5;
        }

        /// <summary>
        /// Append an encoded signed 32 bit integer to the message buffer
        /// </summary>
        /// <param name="Slot">Presence map slot</param>
        /// <param name="Value">Signed 32 bit integer</param>
        /// <returns>Number of bytes appended</returns>
        public int EmitI32(int Slot, int Value)
        {
            int Size = I32ToSize(Value);

            switch (Size)
            {
                // Shifts are arithmetic (signed)
                // The sign bit of Value will be copied on right shifts

                case 5: 
                    EmitByte((byte)((Value >> 28) & 0x7f));
                    EmitByte((byte)((Value >> 21) & 0x7f));
                    EmitByte((byte)((Value >> 14) & 0x7f));
                    EmitByte((byte)((Value >> 7) & 0x7f));
                    EmitByte((byte)((Value & 0x7f) | 0x80));
                    break;

                case 4:
                    EmitByte((byte)((Value >> 21) & 0x7f));
                    EmitByte((byte)((Value >> 14) & 0x7f));
                    EmitByte((byte)((Value >> 7) & 0x7f));
                    EmitByte((byte)((Value & 0x7f) | 0x80));
                    break;

                case 3:
                    EmitByte((byte)((Value >> 14) & 0x7f));
                    EmitByte((byte)((Value >> 7) & 0x7f));
                    EmitByte((byte)((Value & 0x7f) | 0x80));
                    break;

                case 2:
                    EmitByte((byte)((Value >> 7) & 0x7f));
                    EmitByte((byte)((Value & 0x7f) | 0x80));
                    break;

                case 1:
                    EmitByte((byte)((Value & 0x7f) | 0x80));
                    break;

                default:
                    throw new Exception("CSERDES, EmitI32: Invalid number of bytes");
            }

            m_PMAP.Set(Slot);

            return Size;
        }

        /// <summary>
        /// Append an encoded unsigned 32 bit integer to the message buffer
        /// </summary>
        /// <param name="Slot">Presence map slot</param>
        /// <param name="Value">Unsigned 32 bit integer</param>
        /// <returns>Number of bytes appended</returns>
        public int EmitU32(int Slot, uint Value)
        {
            int Size = U32ToSize(Value);

            switch (Size)
            {
                // Shifts are logical (unsigned)
                case 5: 
                    EmitByte((byte) (Value >> 28));
                    EmitByte((byte) ((Value >> 21) & 0x7f));
                    EmitByte((byte) ((Value >> 14) & 0x7f));
                    EmitByte((byte) ((Value >> 7) & 0x7f));
                    EmitByte((byte) ((Value & 0x7f) | 0x80));
                    break;

                case 4: 
                    EmitByte((byte) ((Value >> 21) & 0x7f));
                    EmitByte((byte) ((Value >> 14) & 0x7f));
                    EmitByte((byte) ((Value >> 7) & 0x7f));
                    EmitByte((byte) ((Value & 0x7f) | 0x80));
                    break;

                case 3: 
                    EmitByte((byte) ((Value >> 14) & 0x7f));
                    EmitByte((byte) ((Value >> 7) & 0x7f));
                    EmitByte((byte) ((Value & 0x7f) | 0x80));
                    break;

                case 2: 
                    EmitByte((byte) ((Value >> 7) & 0x7f));
                    EmitByte((byte) ((Value & 0x7f) | 0x80));
                    break;

                case 1: 
                    EmitByte((byte) ((Value & 0x7f) | 0x80));
                    break;

                default:
                    throw new Exception("CSERDES, EmitU32: Invalid number of bytes");
            }

            m_PMAP.Set(Slot);

            return Size;
        }

        /// <summary>
        /// Appends an encoded string to the message buffer
        /// </summary>
        /// <param name="Slot">Presence map slot</param>
        /// <param name="Value">String value</param>
        /// <returns>Number of bytes appended</returns>
        public int EmitString(int Slot, string Value)
        {
            if (Value.Length <= 0)
            {
                throw new Exception("CSERDES, EmitString: String length must be > 0");
            }

            int Size = Value.Length;

            int Index;

            for (Index=0; Index <Size - 1; Index++)
            {
                EmitByte((byte)Value[Index]);
            }

            byte LastByte = (byte)(Value[Index] | 0x80);
            EmitByte(LastByte);

            m_PMAP.Set(Slot);

            return Size;
        }

        /// <summary>
        /// Flush buffer to output stream
        /// </summary>
        public void Flush()
        {
            FlushPMAP();
            FlushMessage();

            m_PMAP.Reset();
            m_MsgSize = 0;
        }

        /// <summary>
        /// Deserialize an SBIT coded field
        /// </summary>
        /// <param name="Data">Buffer for derserialized data</param>
        /// <param name="Size">Size of the buffer</param>
        /// <returns>Number of bytes read from the input stream</returns>
        private int ParseBytes(ref byte[] Data, int Size)
        {
            try
            {
                bool StopBitFound = false;
                int Index = 0;

                while (!StopBitFound)
                {
                    if (Index > Size)
                    {
                        throw new Exception("CSERDES, ParseBytes: buffer overflow");
                    }

                    byte Byte = m_BR.ReadByte();

                    if (Byte >= 0x80)
                    {
                        Data[Index++] = (byte)(Byte & 0x7f);
                        StopBitFound = true;
                    }
                    else
                    {
                        Data[Index++] = Byte;
                    }
                }

                return Index;
            }
            catch (Exception E)
            {
                if (E is EndOfStreamException)
                {
                    return 0;
                }
                else
                {
                    throw E;
                }
            }
        }

        /// <summary>
        /// Parses the presence map from the input stream.
        /// </summary>
        /// <returns>Number of bytes read</returns>
        public int ParsePMAP()
        {
           int Bytes = ParseBytes(ref m_ParseBuffer, PARSE_BUFFER_SIZE);
           int Offset = 0;
           int Idx = 0;

           if (Bytes > 0)
           {
                for (Idx = 0, Offset = 0; Idx < Bytes; Idx++, Offset += 7)
                {
                   uint Temp = m_ParseBuffer[Idx];

                   for (int SubIdx = 0; SubIdx < 7; SubIdx++)
                   {
                       if ((Temp & m_BitMask[SubIdx]) != 0)
                       {
                           m_PMAP.Bits[Offset + SubIdx] = true;
                       }
                       else
                       {
                           m_PMAP.Bits[Offset + SubIdx] = false;
                       }
                   }
                }

                m_PMAP.Size = 7 * Bytes;
            }

            return Bytes;
        }

        /// <summary>
        /// Parses a 32 bit signed or unsigned value.
        /// </summary>
        /// <param name="Value">Value to be parsed</param>
        /// <param name="SignMask">Signed / unsigned flag</param>
        /// <returns>Number of bytes parsed</returns>
        private int Parse32(ref uint Value, int SignMask)
        {
            int Bytes = ParseBytes(ref m_ParseBuffer, PARSE_BUFFER_SIZE);

            if (Bytes > 0)
            {
               int Temp = 0;

               if ((m_ParseBuffer[0] & SignMask) != 0)
               {
                   Temp = -1;
               }

               for (int Idx = 0; Idx < Bytes; Idx++)
               {
                   Temp = (Temp << 7) | m_ParseBuffer[Idx];
               }

               Value = (uint) Temp;
            }

            return Bytes;
        }

        /// <summary>
        /// Parses an unsigned 32 bit value from the input stream.
        /// </summary>
        /// <param name="Slot">Presence map slot</param>
        /// <param name="Value">Value to be parsed</param>
        /// <returns>Number of bytes parsed</returns>
        public int ParseU32(int Slot, ref uint Value)
        {
            int Bytes = 0;
            Value = 0;

            if (m_PMAP.Get(Slot))
            {
                Bytes = Parse32(ref Value, SIGN_MASK_U32);
            }

            return Bytes;
        }

        /// <summary>
        /// Parses a signed 32 bit value from the input stream.
        /// </summary>
        /// <param name="Slot">Presence map slot</param>
        /// <param name="Value">Value to be parsed</param>
        /// <returns>Number of bytes parsed</returns>
        public int ParseI32(int Slot, ref int Value)
        {
            int Bytes = 0;
            Value = 0;

            if (m_PMAP.Get(Slot))
            {
                uint Temp = 0;
                Bytes = Parse32(ref Temp, SIGN_MASK_I32);
                Value = (int) Temp;
            }

            return Bytes;
        }

        /// <summary>
        /// Parses a string value from the input stream.
        /// </summary>
        /// <param name="Slot">Presence map slot</param>
        /// <param name="Value">Value to be parsed</param>
        /// <returns>Number of bytes parsed</returns>
        public int ParseString(int Slot, ref string Value)
        {
            bool StopBitFound = false;
            int Size = 0;
            Value = "";

            if (m_PMAP.Get(Slot))
            {
                while (!StopBitFound)
                {
                    byte Byte = m_BR.ReadByte();

                    if (Byte >= 0x80)
                    {
                        Byte &= 0x7f;
                        Value += (char) Byte;
                        StopBitFound = true;
                    }
                    else
                    {
                        Value += (char) Byte;
                    }

                    Size++;
                }
            }

            return Size;
        }
    }
}
