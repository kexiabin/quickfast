// FIX Adapted for STreaming (sm) (FAST Protocol (sm)) 
//
// Copyright (c) 2005-2006, Rapid Addition Ltd (http://www.rapidaddition.com)
// Copyright (c) 2005-2006, Pantor Engineering AB (http://www.pantor.com)
// Copyright (c) 2005-2006, SpryWare LLC (http://www.spryware.com)
// Copyright (c) 2005-2006, FIX Protocol Ltd (http://www.fixprotocol.org)
// All Rights Reserved.
//
// This work is distributed under the W3C� Software License [1] in the
// hope that it will be useful, but WITHOUT ANY WARRANTY; without even the
// implied warranty of MERCHANTABILITY, SATISFACTORY QUALITY or FITNESS 
// FOR A PARTICULAR PURPOSE.
//
// [1] http://www.w3.org/Consortium/Legal/2002/copyright-software-20021231
// [FPL's Intellectual Property details] http://www.fixprotocol.org/ip
// [FAST Protocol details] http://www.fixprotocol.org/fast
// [FAST Protocol credits] http://fixprotocol.org/fastcredits

using System;
using System.IO;
using System.Collections;
using System.Text;

namespace FAST
{
    /// <summary>
    /// The CCOCEC class is the base class for codecs (encoders / decoders).
    /// </summary>
    public class CCODEC
    {
        private enum state
        {
            Idle,
            DecodingMessage,
            EncodingMessage
        }

        private ArrayList m_FieldDefs = new ArrayList();
        private CTransferEncoder m_Serdes;
        private ArrayList m_CVs;
        private state m_State;

        /// <summary>
        /// Codec constructor, used when creating a codec (encoder / decoder) instance.
        /// </summary>
        /// <param name="Serdes">SERDES to be used during encoding/decoding process</param>
        /// <param name="NoTemplates">Number of templates utilised</param>
        /// <param name="NoSlots">Number of slots utilised</param>
        public CCODEC(CTransferEncoder Serdes, int NoTemplates, int NoSlots)
        {
            m_Serdes = Serdes;

            m_CVs = new ArrayList();

            for (int Index = 0; Index < NoTemplates; Index++)
            {
                m_CVs.Add(new CCurrentValue(NoSlots));
            }
        }

        /// <summary>
        /// Adds a new field definition to the CODEC. The field definition specifies how a 
        /// field should be encoded (operator) and the slot to use for the field as well as
        /// the field data type.
        /// </summary>
        /// <param name="ID">Field identifier</param>
        /// <param name="Type">Field data type</param>
        /// <param name="Op">Field encoding operation</param>
        /// <param name="TID">Field template to use</param>
        /// <param name="Slot">Field slot</param>
        public void AddFieldDef(int ID, CFieldDef.type Type, CFieldDef.op Op, int TID, int Slot)
        {
            if (ID != m_FieldDefs.Count)
            {
                throw new Exception("CCODEC, AddFieldDef: Must be called in sequence of slots");
            }

            CFieldDef FieldDef = new CFieldDef(ID, Type, Op, TID, Slot);
            m_FieldDefs.Add(FieldDef);
        }

        /// <summary>
        /// Starts the decode of the next message. Parses the presence map in start of decode 
        /// new message.
        /// </summary>
        /// <returns>Number of bytes read in the PMAP</returns>
        public int DecodeNewMsg(uint Tag)
        {
            if (m_State != state.Idle)
            {
                throw new Exception("CCODEC, DecodeEndMsg: Must be called when not decoding or encoding a message");
            }

            m_State = state.DecodingMessage;
            return m_Serdes.ParsePMAP();
        }

        /// <summary>
        /// Completes the decoding of a message. This function must be called after 
        /// the last tag of a message has been decoded.
        /// </summary>
        public void DecodeEndMsg()
        {
            if (m_State != state.DecodingMessage)
            {
                throw new Exception("CCODEC, DecodeEndMsg: Must be called after DecodeNewMsg");
            }

            m_State = state.Idle;
        }

        /// <summary>
        /// Decode an ASCII string value.
        /// </summary>
        /// <param name="TagIdx">Tag</param>
        /// <param name="Data">Data to be decoded</param>
        /// <returns>Number of bytes read</returns>
        public int DecodeString(int TagIdx, ref string Data)
        {
            if (m_State != state.DecodingMessage)
            {
                throw new Exception("CCODEC, DecodeString: Must be called within DecodeNewMsg, DecodeEndMsg");
            }

            int Bytes = 0;

            CFieldDef FieldDef = (CFieldDef) m_FieldDefs[TagIdx];
            int Slot = FieldDef.Slot;

            if (FieldDef.Type != CFieldDef.type.String)
            {
                throw new Exception("CCODEC, DecodeString: Field data type is invalid");
            }

            CCurrentValue CV = (CCurrentValue) m_CVs[FieldDef.TID];

            switch (FieldDef.OP)
            {
                case CFieldDef.op.None:

                    Bytes = m_Serdes.ParseString(Slot, ref Data);

                    if (Bytes == 0)
                    {
                        throw new Exception("CCODEC, DecodeString: Invalid value for FAST_OP_NONE operation");
                    }

                    break;

                case CFieldDef.op.Copy:

                    Bytes = m_Serdes.ParseString(Slot, ref Data);

                    if (Bytes == 0) // Copy current value
                    {
                        Data = CV.GetString(Slot);
                    }
                    else // Set current value
                    {
                        CV.SetString(Slot, Data);
                    }

                    break;

                case CFieldDef.op.Delta:
                    {
                        string Delta = "";
                        string Current = "";

                        if (CV.IsValid(Slot))
                        {
                            Current = CV.GetString(Slot);
                        }

                        Bytes = m_Serdes.ParseString(Slot, ref Delta);

                        if (Current.Length > 0)
                        {
                            Data = Current + Delta;
                            CV.SetString(Slot, Data);
                        }
                        else
                        {
                            Data = Delta;
                            CV.SetString(Slot, Delta);
                        }
                    }

                    break;

                default:
                    throw new Exception("CCODEC, DecodeString: Operator is not valid for data type String");
            }

            return Bytes;
        }

        /// <summary>
        /// Decode a signed 32 bit integer value.
        /// </summary>
        /// <param name="TagIdx">Tag</param>
        /// <param name="Data">Data to be decoded</param>
        /// <returns>Number of bytes read</returns>
        public int DecodeI32(int TagIdx, ref int Data)
        {
            if (m_State != state.DecodingMessage)
            {
                throw new Exception("CCODEC, DecodeI32: Must be called within DecodeNewMsg, DecodeEndMsg");
            }

            int Bytes = 0;

            CFieldDef FieldDef = (CFieldDef) m_FieldDefs[TagIdx];
            int Slot = FieldDef.Slot;

            if (FieldDef.Type != CFieldDef.type.I32)
            {
                throw new Exception("CCODEC, DecodeI32: Field data type is invalid");
            }

            CCurrentValue CV = (CCurrentValue) m_CVs[FieldDef.TID];

            switch (FieldDef.OP)
            {
                case CFieldDef.op.None: // Value must be present

                    Bytes = m_Serdes.ParseI32(Slot, ref Data);

                    if (Bytes <= 0)
                    {
                        throw new Exception("CCODEC, DecodeI32: Invalid value for FAST_OP_NONE operation");
                    }

                    break;

                case CFieldDef.op.Copy: // Use previous value if not present

                    Bytes = m_Serdes.ParseI32(Slot, ref Data);

                    if (Bytes < 0)
                    {
                        throw new Exception("CCODEC, DecodeI32: End of stream");
                    }
                    else if (Bytes > 0) // Set current value
                    {
                        CV.SetI32(Slot, Data);
                    }
                    else if (Bytes == 0) // No value - copy current value
                    {
                        Data = CV.GetI32(Slot);
                    }

                    break;

                case CFieldDef.op.Incr: // Use previous value plus one if not present

                    Bytes = m_Serdes.ParseI32(Slot, ref Data);

                    if (Bytes < 0)
                    {
                        throw new Exception("CCODEC, DecodeI32: End of stream");
                    }
                    else if (Bytes > 0) // Set current value
                    {
                        CV.SetI32(Slot, Data);
                    }
                    else if (Bytes == 0) // No value - use previous plus one
                    {
                        Data = CV.GetI32(Slot) + 1;
                        CV.SetI32(Slot, Data);
                    }

                    break;

                case CFieldDef.op.Delta:

                    if (CV.IsValid(Slot))
                    {
                        // Rule: delta defaults to ZERO if there is
                        // no value present

                        int Delta = 0;

                        Bytes = m_Serdes.ParseI32(Slot, ref Delta);

                        if (Bytes < 0)
                        {
                            throw new Exception("CCODEC, DecodeI32: End of stream");
                        }
                        else if (Bytes > 0) // Set current value
                        {
                            Data = CV.GetI32(Slot) + Delta;
                            CV.SetI32(Slot, Data);
                        }
                    }
                    else
                    {
                        // Rule: A field must be present if the
                        // current value isn't valid

                        Bytes = m_Serdes.ParseI32(Slot, ref Data);

                        if (Bytes < 0)
                        {
                            throw new Exception("CCODEC, DecodeI32: End of stream");
                        }
                        else if (Bytes == 0)
                        {
                            throw new Exception("CCODEC, DecodeI32: Invalid value for FAST_OP_NONE operation");
                        }
                        else
                        {
                            CV.SetI32(Slot, Data);
                        }
                    }

                    break;

                default:
                    throw new Exception("CCODEC, DecodeI32: Operator is not valid for data type FAST_TYPE_I32");
            }

           return Bytes;
        }

        /// <summary>
        /// Decode an unsigned 32 bit integer value.
        /// </summary>
        /// <param name="TagIdx">Tag</param>
        /// <param name="Data">Data to be decoded</param>
        /// <returns>Number of bytes read</returns>
        public int DecodeU32(int TagIdx, ref uint Data)
        {
            if (m_State != state.DecodingMessage)
            {
                throw new Exception("CCODEC, DecodeU32: Must be called within DecodeNewMsg, DecodeEndMsg");
            }

            int Bytes = 0;

            CFieldDef FieldDef = (CFieldDef) m_FieldDefs[TagIdx];
            int Slot = FieldDef.Slot;

            if (FieldDef.Type != CFieldDef.type.U32)
            {
                throw new Exception("CCODEC, DecodeU32: Field data type is invalid");
            }

            CCurrentValue CV = (CCurrentValue) m_CVs[FieldDef.TID];

            switch (FieldDef.OP)
            {
                case CFieldDef.op.None: // Value must be present

                    Bytes = m_Serdes.ParseU32(Slot, ref Data);

                    if (Bytes <= 0)
                    {
                        throw new Exception("CCODEC, DecodeU32: Invalid value for FAST_OP_NONE operation");
                    }

                    break;

                case CFieldDef.op.Copy: // Use previous value if not present

                    Bytes = m_Serdes.ParseU32(Slot, ref Data);

                    if (Bytes < 0)
                    {
                        throw new Exception("CCODEC, DecodeU32: End of stream");
                    }
                    else if (Bytes > 0) // Set current value
                    {
                        CV.SetU32(Slot, Data);
                    }
                    else if (Bytes == 0) // No value - copy current value
                    {
                        Data = CV.GetU32(Slot);
                    }

                    break;

                case CFieldDef.op.Incr: // Use previous value plus one if not present

                    Bytes = m_Serdes.ParseU32(Slot, ref Data);

                    if (Bytes < 0)
                    {
                        throw new Exception("CCODEC, DecodeU32: End of stream");
                    }
                    else if (Bytes > 0) // Set current value
                    {
                        CV.SetU32(Slot, Data);
                    }
                    else if (Bytes == 0) // No value - use previous plus one
                    {
                        Data = CV.GetU32(Slot) + 1;
                        CV.SetU32(Slot, Data);
                    }

                    break;

                case CFieldDef.op.Delta:

                    if (CV.IsValid(Slot))
                    {
                        // Rule: delta defaults to ZERO if there is
                        // no value present

                        int Delta = 0;

                        Bytes = m_Serdes.ParseI32(TagIdx, ref Delta);

                        if (Bytes < 0)
                        {
                            throw new Exception("CCODEC, DecodeU32: End of stream");
                        }
                        else if (Bytes > 0) // Set current value
                        {
                            Data = (uint) ((int) CV.GetU32(Slot) + Delta);
                            CV.SetU32(Slot, Data);
                        }
                    }
                    else
                    {
                        // Rule: A field must be present if the
                        // current value isn't valid

                        Bytes = m_Serdes.ParseU32(Slot, ref Data);

                        if (Bytes < 0)
                        {
                            throw new Exception("CCODEC, DecodeU32: End of stream");
                        }
                        else if (Bytes == 0)
                        {
                            throw new Exception("CCODEC, DecodeU32: Invalid value for FAST_OP_DELTA operation");
                        }
                        else
                        {
                            CV.SetU32(Slot, Data);
                        }
                    }

                    break;

                default:
                    throw new Exception("CCODEC, DecodeU32: Operator is not valid for data type FAST_TYPE_U32");
            }

            return Bytes;
        }

        /// <summary>
        /// Writes the current pmap and message data to the output stream.
        /// This will also be called from other sites when repeating groups become
        /// supported in this implementation.
        /// </summary>
        /// <returns></returns>
        private int FlushGroup()
        {
            m_Serdes.Flush();
            return 0;
        }

        /// <summary>
        /// Flush the last group of the message and write serialized data
        /// </summary>
        /// <returns></returns>
        private int FlushMsg()
        {
            FlushGroup();
            return 0;
        }

        /// <summary>
        /// Called to setup encoding for a message. It must not be called again without 
        /// calling EncodeEndMsg in between.
        /// </summary>
        /// <param name="TagIdx">Field identifier</param>
        /// <returns>Number of bytes encoded</returns>
        public int EncodeNewMsg(uint TagIdx)
        {
            if (m_State != state.Idle)
            {
                throw new Exception("CCODEC, EncodeNewMsg: Must be called when not decoding or encoding a message");
            }

            m_State = state.EncodingMessage;

            return 0;
        }

        /// <summary>
        /// Finish encoding a message
        /// </summary>
        /// <returns>Number of bytes encoded</returns>
        public int EncodeEndMsg()
        {
            if (m_State != state.EncodingMessage)
            {
                throw new Exception("CCODEC, EncodeEndMsg: Must be called after EncodeNewMsg");
            }

            m_State = state.Idle;

            return FlushMsg();
        }

        /// <summary>
        /// Find position of first difference between strings
        /// </summary>
        /// <param name="S1">First string</param>
        /// <param name="S2">Second string for comparison</param>
        /// <returns></returns>
        private int FindCharDeltaOffset(string S1, string S2)
        {
            int Index;

            for (Index = 0; Index < S1.Length; Index++)
            {
                if (S1[Index] != S2[Index])
                {
                    break;
                }
            }

            return Index;
        }

        /// <summary>
        /// Encode an ASCII string
        /// </summary>
        /// <param name="TagIdx">Field identifier</param>
        /// <param name="Value">Value to be encoded</param>
        /// <returns>Number of bytes encoded</returns>
        public int EncodeString(int TagIdx, string Value)
        {
            if (m_State != state.EncodingMessage)
            {
                throw new Exception("CCODEC, EncodeString: Must be called within EncodeNewMsg, EncodeEndMsg");
            }

            int Bytes = 0;
            CFieldDef FieldDef = (CFieldDef) m_FieldDefs[TagIdx];
            int Slot = FieldDef.Slot;
            CCurrentValue CV = (CCurrentValue) m_CVs[FieldDef.TID];

            if (FieldDef.Type != CFieldDef.type.String)
            {
                throw new Exception("CCODEC, EncodeString: Field data type is invalid");
            }

            switch (FieldDef.OP)
            {
                case CFieldDef.op.None: // Always emit value

                    CV.SetString(Slot, Value);
                    Bytes = m_Serdes.EmitString(Slot, Value);

                    break;

                case CFieldDef.op.Copy: // Emit value if not equal to previous value

                    if (CV.GetString(Slot) != Value)
                    {
                        CV.SetString(Slot, Value);
                        Bytes = m_Serdes.EmitString(Slot, Value);
                    }

                    break;

                case CFieldDef.op.Delta: // Emit delta between current and new value
                    {
                        string Current = CV.GetString(Slot);

                        int Offset = 0;

                        if (Current != null)
                        {
                            Offset = FindCharDeltaOffset(Current, Value);
                        }

                        if (Offset != Value.Length)
                        {
                            CV.SetString(Slot, Value);
                            Bytes = m_Serdes.EmitString(Slot, Value.Substring(Offset));
                        }

                        break;
                    }

                default:
                    throw new Exception("CCODEC, EncodeString: Field operator is invalid");
            }

            return Bytes;
        }

        /// <summary>
        /// Encode an unsigned 32 bit integer
        /// </summary>
        /// <param name="TagIdx">Field identifier</param>
        /// <param name="Value">Value to be encoded</param>
        /// <returns>Number of bytes encoded</returns>
        public int EncodeU32(int TagIdx, uint Value)
        {
            if (m_State != state.EncodingMessage)
            {
                throw new Exception("CCODEC, EncodeU32: Must be called within EncodeNewMsg, EncodeEndMsg");
            }

            int Bytes = 0;
            CFieldDef FieldDef = (CFieldDef) m_FieldDefs[TagIdx];
            int Slot = FieldDef.Slot;
            CCurrentValue CV = (CCurrentValue) m_CVs[FieldDef.TID];

            if (FieldDef.Type != CFieldDef.type.U32)
            {
                throw new Exception("CCODEC, EncodeU32: Field data type is invalid");
            }

            switch (FieldDef.OP)
            {
                case CFieldDef.op.None: // Always emit value
                    CV.SetU32(Slot, Value); // update current value state
                    Bytes = m_Serdes.EmitU32(Slot, Value); // emit the value
                    break;

                case CFieldDef.op.Copy: // Emit value if not equal to previous value

                    if (CV.GetU32(Slot) != Value)
                    {
                        CV.SetU32(Slot, Value); // update current value state
                        Bytes = m_Serdes.EmitU32(Slot, Value); // emit the value
                    }

                    break;

                case CFieldDef.op.Incr: // Emit value if not previous value plus one

                    if (CV.GetU32(Slot) == Value)
                    {
                        CV.SetU32(Slot, Value + 1); // update current value state
                    }
                    else
                    {
                        CV.SetU32(Slot, Value + 1); // update current value state
                        Bytes = m_Serdes.EmitU32(Slot, Value); // emit the value
                    }

                    break;

                case CFieldDef.op.Delta: // Emit change in value if not equal to previous

                    if (CV.IsValid(Slot))
                    {
                        int Delta = (int) Value - (int) CV.GetU32(Slot);

                        if (Delta != 0)
                        {
                            CV.SetU32(Slot, Value); // update current value state
                            Bytes = m_Serdes.EmitI32(Slot, Delta); // emit the value
                        }
                    }
                    else
                    {
                        CV.SetU32(Slot, Value); // update current value state
                        Bytes = m_Serdes.EmitU32(Slot, Value); // emit the value
                    }

                    break;

                default:
                    throw new Exception("CCODEC, EncodeU32: Field operator is invalid");
            }

            return Bytes;
        }

        /// <summary>
        /// Encode a signed 32 bit integer
        /// </summary>
        /// <param name="TagIdx">Field identifier</param>
        /// <param name="Value">Value to be encoded</param>
        /// <returns>Number of bytes encoded</returns>
        public int EncodeI32(int TagIdx, int Value)
        {
            if (m_State != state.EncodingMessage)
            {
                throw new Exception("CCODEC, EncodeI32: Must be called within EncodeNewMsg, EncodeEndMsg");
            }

            int Bytes = 0;
            CFieldDef FieldDef = (CFieldDef) m_FieldDefs[TagIdx];
            int Slot = FieldDef.Slot;
            CCurrentValue CV = (CCurrentValue) m_CVs[FieldDef.TID];

            if (FieldDef.Type != CFieldDef.type.I32)
            {
                throw new Exception("CCODEC, EncodeI32: Field data type is invalid");
            }

            switch (FieldDef.OP)
            {
                case CFieldDef.op.None: // Always emit value
                    CV.SetI32(Slot, Value); // update current value state
                    Bytes = m_Serdes.EmitI32(Slot, Value); // emit the value
                    break;

                case CFieldDef.op.Copy: // Emit value if not equal to previous value

                    if (CV.GetI32(Slot) != Value)
                    {
                        CV.SetI32(Slot, Value); // update current value state
                        Bytes = m_Serdes.EmitI32(Slot, Value); // emit the value
                    }

                    break;

                case CFieldDef.op.Incr: // Emit value if not previous value plus one

                    if (CV.GetI32(Slot) == Value)
                    {
                        CV.SetI32(Slot, Value + 1); // update current value state
                    }
                    else
                    {
                        CV.SetI32(Slot, Value + 1); // update current value state
                        Bytes = m_Serdes.EmitI32(Slot, Value); // emit the value
                    }

                    break;

                case CFieldDef.op.Delta: // Emit change in value if not equal to previous

                    if (CV.IsValid(Slot))
                    {
                        int Delta = Value - CV.GetI32(Slot);

                        if (Delta != 0)
                        {
                            CV.SetI32(Slot, Value); // update current value state
                            Bytes = m_Serdes.EmitI32(Slot, Delta); // emit the value
                        }
                    }
                    else
                    {
                        CV.SetI32(FieldDef.Slot, Value); // update current value state
                        Bytes = m_Serdes.EmitI32(Slot, Value); // emit the value
                    }

                    break;

                default:
                    throw new Exception("CCODEC, EncodeI32: Field operator is invalid");
            }

            return Bytes;
        }
    }
}
