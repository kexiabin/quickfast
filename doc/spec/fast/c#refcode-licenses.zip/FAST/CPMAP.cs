// FIX Adapted for STreaming (sm) (FAST Protocol (sm)) 
//
// Copyright (c) 2005-2006, Rapid Addition Ltd (http://www.rapidaddition.com)
// Copyright (c) 2005-2006, Pantor Engineering AB (http://www.pantor.com)
// Copyright (c) 2005-2006, SpryWare LLC (http://www.spryware.com)
// Copyright (c) 2005-2006, FIX Protocol Ltd (http://www.fixprotocol.org)
// All Rights Reserved.
//
// This work is distributed under the W3C� Software License [1] in the
// hope that it will be useful, but WITHOUT ANY WARRANTY; without even the
// implied warranty of MERCHANTABILITY, SATISFACTORY QUALITY or FITNESS 
// FOR A PARTICULAR PURPOSE.
//
// [1] http://www.w3.org/Consortium/Legal/2002/copyright-software-20021231
// [FPL's Intellectual Property details] http://www.fixprotocol.org/ip
// [FAST Protocol details] http://www.fixprotocol.org/fast
// [FAST Protocol credits] http://fixprotocol.org/fastcredits

using System;
using System.Collections;
using System.Text;

namespace FAST
{
    /// <summary>
    /// The CPMAP class keeps track of the presence / absence of a field
    /// from the encoded data stream.
    /// </summary>
    class CPMAP
    {
        /// <summary>
        /// Presence map. One item for each slot.
        /// </summary>
        bool[] m_Bits;
        /// <summary>
        /// Utilised size of the presence map.
        /// </summary>
        int m_Size;
        /// <summary>
        /// Number of slots available in the presence map.
        /// </summary>
        int m_NoSlots;

        /// <summary>
        /// Constructor
        /// </summary>
        /// <param name="NoSlots">Number of slots required in the presence map</param>
        public CPMAP(int NoSlots)
        {
            m_NoSlots = NoSlots;
            m_Bits = new bool[NoSlots];
        }

        /// <summary>
        /// Presence map.
        /// </summary>
        public bool[] Bits
        {
            get { return m_Bits; }
        }

        /// <summary>
        /// Get / Set the utilised size of the presence map.
        /// </summary>
        public int Size
        {
            get {return m_Size;}
            set {m_Size = value;}
        }

        /// <summary>
        /// Resets the state of the presence map. All slots are marked
        /// as absent.
        /// </summary>
        public void Reset()
        {
            for (int Idx = 0; Idx < m_Size; Idx++)
            {
                m_Bits[Idx] = false;
            }

            m_Size = 0;
        }

        /// <summary>
        /// Gets the presence / absence of a field slot.
        /// </summary>
        /// <param name="Slot">Field slot</param>
        /// <returns>true if slot is present, otherwise false</returns>
        public bool Get(int Slot)
        {
            if (Slot >= m_NoSlots)
            {
                throw new Exception("CPMAP, Get: Slot value is too big");
            }

            return m_Bits[Slot];
        }

        /// <summary>
        /// Sets the presence / absence of a field slot
        /// </summary>
        /// <param name="Slot">Field slot</param>
        public void Set(int Slot)
        {
            if (Slot >= m_NoSlots)
            {
                throw new Exception("CPMAP, Set: Slot value is too big");
            }

            if (Slot + 1 > m_Size)
            {
                m_Size = Slot + 1;
            }

            m_Bits[Slot] = true;
        }    
    }
}
