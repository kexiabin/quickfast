// FIX Adapted for STreaming (sm) (FAST Protocol (sm)) 
//
// Copyright (c) 2005-2006, Rapid Addition Ltd (http://www.rapidaddition.com)
// Copyright (c) 2005-2006, Pantor Engineering AB (http://www.pantor.com)
// Copyright (c) 2005-2006, SpryWare LLC (http://www.spryware.com)
// Copyright (c) 2005-2006, FIX Protocol Ltd (http://www.fixprotocol.org)
// All Rights Reserved.
//
// This work is distributed under the W3C� Software License [1] in the
// hope that it will be useful, but WITHOUT ANY WARRANTY; without even the
// implied warranty of MERCHANTABILITY, SATISFACTORY QUALITY or FITNESS 
// FOR A PARTICULAR PURPOSE.
//
// [1] http://www.w3.org/Consortium/Legal/2002/copyright-software-20021231
// [FPL's Intellectual Property details] http://www.fixprotocol.org/ip
// [FAST Protocol details] http://www.fixprotocol.org/fast
// [FAST Protocol credits] http://fixprotocol.org/fastcredits

using System;

namespace FAST
{
	/// <summary>
	/// The CCurrentValue class holds the current value information for
	/// each slot. The current value information is used to implement the
	/// operators such as copy, increment, delta.
	/// </summary>

	public class CCurrentValue
	{
        /// <summary>
        /// Number of slots that will be used
        /// </summary>
        private int m_NoSlots;

        /// <summary>
		/// Current signed integer 32 values
		/// </summary>
		private int[] m_I32Values;

		/// <summary>
		/// Current unsigned integer 32 values
		/// </summary>
		private uint[] m_U32Values;

		/// <summary>
		/// Current string values
		/// </summary>
		private string[] m_StringValues;

		/// <summary>
		/// Current valid values indicator
		/// </summary>
		private bool[] m_Valid;

		/// <summary>
		/// Deafult constructor.
		/// </summary>
		public CCurrentValue(int NoSlots)
		{
            m_NoSlots = NoSlots;
            m_I32Values = new int[NoSlots];
            m_U32Values = new uint[NoSlots];
            m_StringValues = new string[NoSlots];
            m_Valid = new bool[NoSlots];
		}

		/// <summary>
		/// Checks if the slot currently contains a valid value.
		/// </summary>
		/// <param name="Slot">Slot to check</param>
		/// <returns>true if it is valid, otherwise false</returns>
		public bool IsValid(int Slot)
		{
			return m_Valid[Slot];
		}

		/// <summary>
		/// Gets the current string value at the specified slot.
		/// </summary>
		/// <param name="Slot">Slot to check</param>
		/// <returns>String value</returns>
		public string GetString(int Slot)
		{
            //if (!IsValid(Slot))
            //    throw new Exception("GetString: Current value not set");

			return m_StringValues[Slot];
		}

		/// <summary>
		/// Gets the current unsigned 32 bit integer value at the specified slot.
		/// </summary>
		/// <param name="Slot">Slot to check</param>
		/// <returns>Unsigned 32 bit integer value</returns>
		public uint GetU32(int Slot)
		{
            //if (!IsValid(Slot))
            //    throw new Exception("GetU32: Current value not set");

            return m_U32Values[Slot];
		}

		/// <summary>
		/// Gets the current signed 32 bit integer value at the specified slot.
		/// </summary>
		/// <param name="Slot">Slot to check</param>
		/// <returns>Signed 32 bit integer value</returns>
		public int GetI32(int Slot)
		{
            //if (!IsValid(Slot))
            //    throw new Exception("GetI32: Current value not set");

			return m_I32Values[Slot];
		}

		/// <summary>
		/// Sets the current string value at the specified slot.
		/// </summary>
		/// <param name="Slot">Slot to check</param>
		/// <param name="Value">Value to be stored</param>
		public void SetString(int Slot, string Value)
		{
			m_StringValues[Slot] = Value;
			m_Valid[Slot] = true;
		}

		/// <summary>
		/// Sets the current unsigned 32 bit integer value at the specified slot.
		/// </summary>
		/// <param name="Slot">Slot to check</param>
		/// <param name="Value">Value to be stored</param>
		public void SetU32(int Slot, uint Value)
		{
			m_U32Values[Slot] = Value;
			m_Valid[Slot] = true;
		}

		/// <summary>
		/// Sets the current signed 32 bit integer value at the specified slot.
		/// </summary>
		/// <param name="Slot">Slot to check</param>
		/// <param name="Value">Value to be stored</param>
		public void SetI32(int Slot, int Value)
		{
			m_I32Values[Slot] = Value;
			m_Valid[Slot] = true;
		}

		/// <summary>
		/// Resets the current valid values to not-set.
		/// </summary>
		public void Reset()
		{
            for (int Index = 0; Index < m_NoSlots; Index++)
            {
                m_Valid[Index] = false;
            }
		}
	}
}
