// FIX Adapted for STreaming (sm) (FAST Protocol (sm)) 
//
// Copyright (c) 2005-2006, Rapid Addition Ltd (http://www.rapidaddition.com)
// Copyright (c) 2005-2006, Pantor Engineering AB (http://www.pantor.com)
// Copyright (c) 2005-2006, SpryWare LLC (http://www.spryware.com)
// Copyright (c) 2005-2006, FIX Protocol Ltd (http://www.fixprotocol.org)
// All Rights Reserved.
//
// This work is distributed under the W3C� Software License [1] in the
// hope that it will be useful, but WITHOUT ANY WARRANTY; without even the
// implied warranty of MERCHANTABILITY, SATISFACTORY QUALITY or FITNESS 
// FOR A PARTICULAR PURPOSE.
//
// [1] http://www.w3.org/Consortium/Legal/2002/copyright-software-20021231
// [FPL's Intellectual Property details] http://www.fixprotocol.org/ip
// [FAST Protocol details] http://www.fixprotocol.org/fast
// [FAST Protocol credits] http://fixprotocol.org/fastcredits

using System;
using System.IO;
using System.Collections;
using System.Text;
using FAST;

namespace Encoder
{
    class Program
    {
        private const int NO_TEMPLATES = 1;
        private const int NO_SLOTS = 7;

        /// <summary>
        /// Test template identifiers
        /// </summary>
        enum tids
        {
           Base = 0,
        };

        /// <summary>
        /// Test field definitions
        /// </summary>
        enum fields
        {
           TID = 0,
           SeqNum = 1,
           Time = 2,
           Symbol = 3,
           Price = 4,
           Shares = 5,
           Exch = 6,
        };

        static void Main(string[] args)
        {
            try
            {
                StreamReader SR = new StreamReader(args[0]);
                FileStream FS = new FileStream(args[1], FileMode.Create);
                BinaryWriter BW = new BinaryWriter(FS);

                CTransferEncoder TransferEncoder = new CTransferEncoder(BW, NO_SLOTS);
                CCODEC Codec = new CCODEC(TransferEncoder, NO_TEMPLATES, NO_SLOTS);

                Codec.AddFieldDef((int)fields.TID, CFieldDef.type.U32, CFieldDef.op.Copy, (int) tids.Base, 0);
                Codec.AddFieldDef((int)fields.SeqNum, CFieldDef.type.U32, CFieldDef.op.Incr, (int) tids.Base, 1);
                Codec.AddFieldDef((int)fields.Time, CFieldDef.type.U32, CFieldDef.op.Copy, (int)tids.Base, 2);
                Codec.AddFieldDef((int)fields.Symbol, CFieldDef.type.String, CFieldDef.op.Copy, (int)tids.Base, 3);
                Codec.AddFieldDef((int)fields.Price, CFieldDef.type.U32, CFieldDef.op.Copy, (int)tids.Base, 4);
                Codec.AddFieldDef((int)fields.Shares, CFieldDef.type.U32, CFieldDef.op.Copy, (int)tids.Base, 5);
                Codec.AddFieldDef((int)fields.Exch, CFieldDef.type.String, CFieldDef.op.Copy, (int)tids.Base, 6);

                string NextLine = SR.ReadLine();

                while (NextLine != null)
                {
                    if (NextLine[0] != ';')
                    {
                        // Encode the data, we always start off with a template ID
                        Codec.EncodeNewMsg((uint)fields.TID);

                        // Always start off with a template ID
                        Codec.EncodeU32((int)fields.TID, (uint) 1);

                        // SeqNum is first 6 chars in input file, starting at pos 0
                        Codec.EncodeU32((int)fields.SeqNum, System.Convert.ToUInt32(NextLine.Substring(0, 6)));
                            
                        // Time is next 6 chars in input file, starting at pos 7
                        Codec.EncodeU32((int)fields.Time, System.Convert.ToUInt32(NextLine.Substring(7, 6)));

                        // Symbol is next 3 chars in input file, starting at pos 14
                        Codec.EncodeString((int)fields.Symbol, NextLine.Substring(14, 3));

                        // Price is next 5 chars in input file, starting at pos 18
                        Codec.EncodeU32((int)fields.Price, System.Convert.ToUInt32(NextLine.Substring(18, 5)));
                            
                        // Shares are next 3 chars in input file, starting at pos 24
                        Codec.EncodeU32((int)fields.Shares, System.Convert.ToUInt32(NextLine.Substring(24, 3)));
                            
                        // Exchange is next char in input file, starting at pos 28
                        Codec.EncodeString((int)fields.Exch, NextLine.Substring(28, 1));

                        // we are done with this message
                        Codec.EncodeEndMsg();
                    }

                    NextLine = SR.ReadLine();
                }

                SR.Close();
                BW.Close();
            }
            catch (Exception E)
            {
                System.Console.WriteLine(E.Message);
            }
        }
    }
}
