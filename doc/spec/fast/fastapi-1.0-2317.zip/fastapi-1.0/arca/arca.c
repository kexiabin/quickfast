// $Id: arca.c,v 1.2 2006/02/09 19:14:25 Daniel.May Exp $
//
// FIX Adapted for STreaming (sm) (FAST Protocol (sm)) 
//
// Copyright (c) 2005-2006, Pantor Engineering AB (http://www.pantor.com)
// Copyright (c) 2005-2006, SpryWare LLC (http://www.spryware.com)
// Copyright (c) 2005-2006, FIX Protocol Ltd (http://www.fixprotocol.org)
// All Rights Reserved.
//
// This work is distributed under the W3C® Software License [1] in the
// hope that it will be useful, but WITHOUT ANY WARRANTY; without even the
// implied warranty of MERCHANTABILITY, SATISFACTORY QUALITY or FITNESS 
// FOR A PARTICULAR PURPOSE.
//
// [1] http://www.w3.org/Consortium/Legal/2002/copyright-software-20021231
// [FPL's Intellectual Property details] http://www.fixprotocol.org/ip
// [FAST Protocol details] http://www.fixprotocol.org/fast
// [FAST Protocol credits] http://fixprotocol.org/fastcredits

#include "arca.h"

static fast_codec_t* arca_codec = NULL;

static int cl_count  = 0;
static int cl_decode = 0;

//////////////////////////////////////////////////////////////////////

static insert_order_msg* swap_insert_order_msg (void* data)
{
   insert_order_msg* msg = (insert_order_msg*) data;

   swap16 (msg->size);
   swap32 (msg->time);
   swap32 (msg->seqno);
   swap32 (msg->order_ref);
   swap32 (msg->shares);
   swap32 (msg->price);

   return msg;
}

static delete_order_msg* swap_delete_order_msg (void* data)
{
   delete_order_msg* msg = (delete_order_msg*) data;

   swap16 (msg->size);
   swap32 (msg->time);
   swap32 (msg->seqno);
   swap32 (msg->order_ref);

   return msg;
}

static modify_order_msg* swap_modify_order_msg (void* data)
{
   modify_order_msg* msg = (modify_order_msg*) data;

   swap16 (msg->size);
   swap32 (msg->time);
   swap32 (msg->seqno);
   swap32 (msg->order_ref);
   swap32 (msg->shares);
   swap32 (msg->price);

   return msg;
}

static imbalance_msg* swap_imbalance_msg (void* data)
{
   imbalance_msg* msg = (imbalance_msg*) data;

   swap16 (msg->size);
   swap32 (msg->time);
   swap32 (msg->seqno);
   swap32 (msg->shares);
   swap32 (msg->total_imbal);
   swap32 (msg->market_imbal);
   swap32 (msg->price);
   swap32 (msg->auction_time);

   return msg;
}
//////////////////////////////////////////////////////////////////////

static u32 decode_str (int tag, u8* data, int size)
{
   fast_decode_str (arca_codec, tag, data, size);
   return 0;
}

static u32 decode_u32 (int tag)
{
   u32 temp;

   fast_decode_u32 (arca_codec, tag, & temp);
   return temp;
}

static i32 decode_i32 (int tag)
{
   i32 temp;

   fast_decode_i32 (arca_codec, tag, & temp);
   return temp;
}

static inline void encode_i32 (u32 tag, i32 value)
{
   fast_encode_u32 (arca_codec, tag, value);
}

static inline void encode_u32 (u32 tag, u32 value)
{
   fast_encode_u32 (arca_codec, tag, value);
}

static inline void encode_str (int tag, u8* data, int size)
{
   size = (int) strnlen ((char*) data, size); // remove trailing NULLs
   fast_encode_str (arca_codec, tag, data, size);
}

//////////////////////////////////////////////////////////////////////

static inline void encode_new_msg (u32 tag)
{
   fast_encode_new_msg (arca_codec, tag);
}

static inline void encode_end_msg (u32 tag)
{
   fast_encode_end_msg (arca_codec, tag);
}

//////////////////////////////////////////////////////////////////////

static void decode_insert_order (int type)
{
   insert_order_msg msg [1];
   u32 secs, msecs;

   memset (msg, 0, sizeof (*msg));

   msg->type = 'A';
   msg->size = sizeof (insert_order_msg) - 4;

   secs  = decode_u32 (TSP_SECS);
   msecs = decode_u32 (TSP_MSECS);

   msg->seqno     = decode_u32 (SEQNO);
   msg->order_ref = decode_u32 (ORDER_REF);
   msg->shares    = decode_u32 (SHARES);
   msg->price     = decode_u32 (PRICE);
   msg->scale     = decode_u32 (SCALE);
   msg->exch_code = decode_u32 (EXCH_CODE);
   msg->sys_code  = decode_u32 (SYS_CODE);
   msg->buy_sell  = decode_u32 (BUY_SELL);

   decode_str (STOCK,     STR_ARGS (msg->stock));
   decode_str (QUOTE_ID,  STR_ARGS (msg->quote_id));

   msg->time = secs * 1000 + msecs;

   swap_insert_order_msg (msg);
   write_n (arca_codec->output->fd, msg, sizeof (*msg));
}

//////////////////////////////////////////////////////////////////////

static void decode_delete_order (int type)
{
   delete_order_msg msg [1];
   u32 secs, msecs;

   memset (msg, 0, sizeof (*msg));

   msg->type = 'D';
   msg->size = sizeof (delete_order_msg) - 4;

   secs  = decode_u32 (TSP_SECS);
   msecs = decode_u32 (TSP_MSECS);

   msg->time = secs * 1000 + msecs;

   msg->seqno     = decode_u32 (SEQNO);
   msg->order_ref = decode_u32 (ORDER_REF);
   msg->exch_code = decode_u32 (EXCH_CODE);
   msg->sys_code  = decode_u32 (SYS_CODE);
   msg->buy_sell  = decode_u32 (BUY_SELL);

   decode_str (STOCK,     STR_ARGS (msg->stock));
   decode_str (QUOTE_ID,  STR_ARGS (msg->quote_id));

   swap_delete_order_msg (msg);
   write_n (arca_codec->output->fd, msg, sizeof (*msg));
}

//////////////////////////////////////////////////////////////////////

static void decode_modify_order (int type)
{
   modify_order_msg msg [1];
   u32 secs, msecs;

   memset (msg, 0, sizeof (*msg));

   msg->type = 'M';
   msg->size = sizeof (modify_order_msg) - 4;

   secs  = decode_u32 (TSP_SECS);
   msecs = decode_u32 (TSP_MSECS);

   msg->time = secs * 1000 + msecs;

   msg->seqno     = decode_u32 (SEQNO);
   msg->order_ref = decode_u32 (ORDER_REF);
   msg->shares    = decode_u32 (SHARES);
   msg->price     = decode_u32 (PRICE);
   msg->scale     = decode_u32 (SCALE);
   msg->exch_code = decode_u32 (EXCH_CODE);
   msg->sys_code  = decode_u32 (SYS_CODE);
   msg->buy_sell  = decode_u32 (BUY_SELL);

   decode_str (STOCK,     STR_ARGS (msg->stock));
   decode_str (QUOTE_ID,  STR_ARGS (msg->quote_id));

   swap_modify_order_msg (msg);
   write_n (arca_codec->output->fd, msg, sizeof (*msg));
}

//////////////////////////////////////////////////////////////////////

static void decode_imbalance (int type)
{
   imbalance_msg msg [1];
   u32 secs, msecs;

   memset (msg, 0, sizeof (*msg));

   msg->type = 'I';
   msg->size = sizeof (imbalance_msg) - 4;

   secs  = decode_u32 (TSP_SECS);
   msecs = decode_u32 (TSP_MSECS);

   msg->time = secs * 1000 + msecs;

   msg->seqno  = decode_u32 (SEQNO);
   msg->shares = decode_u32 (SHARES);
   
   msg->price     = decode_u32 (PRICE);
   msg->scale     = decode_u32 (SCALE);

   msg->exch_code = decode_u32 (EXCH_CODE);
   msg->sys_code  = decode_u32 (SYS_CODE);

   decode_str (STOCK, STR_ARGS (msg->stock));

   msg->market_imbal = decode_i32 (MARKET_IMBAL);
   msg->total_imbal  = decode_i32 (TOTAL_IMBAL);

   msg->auction_type = decode_u32 (AUCT_TYPE);
   msg->auction_time = decode_u32 (AUCT_TIME);

   swap_imbalance_msg (msg);
   write_n (arca_codec->output->fd, msg, sizeof (*msg));
}

//////////////////////////////////////////////////////////////////////

static int encode_insert_order (insert_order_msg* msg)
{
   encode_new_msg (ARCA_BASE_TID);

   encode_u32 (MSG_TYPE,  msg->type);
   encode_u32 (TSP_SECS,  msg->time / 1000);
   encode_u32 (TSP_MSECS, msg->time % 1000);

   encode_u32 (SEQNO,     msg->seqno);
   encode_u32 (ORDER_REF, msg->order_ref);
   encode_u32 (SHARES,    msg->shares);
   encode_u32 (PRICE,     msg->price);
   encode_u32 (SCALE,     msg->scale);

   encode_u32 (EXCH_CODE, msg->exch_code);
   encode_u32 (SYS_CODE,  msg->sys_code);
   encode_u32 (BUY_SELL,  msg->buy_sell);

   encode_str (STOCK,     STR_ARGS (msg->stock));
   encode_str (QUOTE_ID,  STR_ARGS (msg->quote_id));

   encode_end_msg (ARCA_BASE_TID);
   return 0;
}

//////////////////////////////////////////////////////////////////////

static int encode_delete_order (delete_order_msg* msg)
{
   encode_new_msg (ARCA_BASE_TID);

   encode_u32 (MSG_TYPE,  msg->type);
   encode_u32 (TSP_SECS,  msg->time / 1000);
   encode_u32 (TSP_MSECS, msg->time % 1000);

   encode_u32 (SEQNO,     msg->seqno);
   encode_u32 (ORDER_REF, msg->order_ref);

   encode_u32 (EXCH_CODE, msg->exch_code);
   encode_u32 (SYS_CODE,  msg->sys_code);
   encode_u32 (BUY_SELL,  msg->buy_sell);

   encode_str (STOCK,     STR_ARGS (msg->stock));
   encode_str (QUOTE_ID,  STR_ARGS (msg->quote_id));

   encode_end_msg (ARCA_BASE_TID);
   return 0;
}

//////////////////////////////////////////////////////////////////////

static int encode_modify_order (modify_order_msg* msg)
{
   encode_new_msg (ARCA_BASE_TID);

   encode_u32 (MSG_TYPE,  msg->type);
   encode_u32 (TSP_SECS,  msg->time / 1000);
   encode_u32 (TSP_MSECS, msg->time % 1000);

   encode_u32 (SEQNO,     msg->seqno);
   encode_u32 (ORDER_REF, msg->order_ref);
   encode_u32 (SHARES,    msg->shares);
   encode_u32 (PRICE,     msg->price);
   encode_u32 (SCALE,     msg->scale);

   encode_u32 (EXCH_CODE, msg->exch_code);
   encode_u32 (SYS_CODE,  msg->sys_code);
   encode_u32 (BUY_SELL,  msg->buy_sell);

   encode_str (STOCK,     STR_ARGS (msg->stock));
   encode_str (QUOTE_ID,  STR_ARGS (msg->quote_id));

   encode_end_msg (ARCA_BASE_TID);
   return 0;
}

//////////////////////////////////////////////////////////////////////

static int encode_imbalance (imbalance_msg* msg)
{
   encode_new_msg (ARCA_BASE_TID);

   encode_u32 (MSG_TYPE,     msg->type);
   encode_u32 (TSP_SECS,     msg->time / 1000);
   encode_u32 (TSP_MSECS,    msg->time % 1000);

   encode_u32 (SEQNO,        msg->seqno);
   encode_u32 (SHARES,       msg->shares);

   encode_u32 (PRICE,        msg->price);
   encode_u32 (SCALE,        msg->scale);

   encode_u32 (EXCH_CODE,    msg->exch_code);
   encode_u32 (SYS_CODE,     msg->sys_code);

   encode_str (STOCK,        STR_ARGS (msg->stock));

   encode_i32 (MARKET_IMBAL, msg->market_imbal);
   encode_i32 (TOTAL_IMBAL,  msg->total_imbal);

   encode_u32 (AUCT_TYPE,    msg->auction_type);
   encode_u32 (AUCT_TIME,    msg->auction_time);

   encode_end_msg (ARCA_BASE_TID);
   return 0;
}

//////////////////////////////////////////////////////////////////////

static int arca_decoder (void)
{
   int count;

   for (count = 1 ;; count ++)
   {
      u32 msg_type;

      if (cl_count > 0 && count > cl_count)
         break;

      if (fast_decode_new_msg (arca_codec, ARCA_BASE_TID) < 0)
         break;

      msg_type = decode_u32 (MSG_TYPE);

      switch (msg_type)
      {
       case 'A':
         decode_insert_order (msg_type);
         break;

       case 'D':
         decode_delete_order (msg_type);
         break;

       case 'M':
         decode_modify_order (msg_type);
         break;

       case 'I':
         decode_imbalance (msg_type);
         break;

       default:
         fprintf (stderr, "fatal: %02x unknown type\n", msg_type);
         exit (0);
      }

      if (fast_decode_end_msg (arca_codec, ARCA_BASE_TID) < 0)
         break;
   }
   return 0;
}

static int arca_encoder (void)
{
   char data [128];

   int error = 0;
   int count;

   for (count = 0 ; cl_count == 0 || count < cl_count ; count ++)
   {
      char* hdr  = data;
      char* body = hdr + 4; // VC can't do arith on void*

      int length;

      // Read four bytes header
      if (read_n (arca_codec->input->fd, data, 4) < 0)
         return -1;

      length = (hdr [0] << 8) | hdr [1];

      assert (length <= sizeof (data) - 4);

      // Read the body part
      if (read_n (arca_codec->input->fd, body, length) < 0)
      {
         perror ("read_n: body part");
         break;
      }

      switch (data [2])
      {
       case 'A':
         encode_insert_order (swap_insert_order_msg (data));
         break;

       case 'D':
         encode_delete_order (swap_delete_order_msg (data));
         break;

       case 'I':
         encode_imbalance (swap_imbalance_msg (data));
         break;

       case 'M':
         encode_modify_order (swap_modify_order_msg (data));
         break;

       default:
         fprintf (stderr, "fatal: unknown type='%c'\n", data [2]);
         abort ();
      }

      if (error != 0)
         break;
   }
   return 0;
}

//////////////////////////////////////////////////////////////////////

#define OPTS "A:c:DV?"

int main (int argc, char* argv [])
{
   init_platform_io ();

   arca_codec = fast_create_codec ();

   assert (arca_codec != NULL);

   for (;;)
   {
      int option = getopt (argc, argv, OPTS);

      if (option == EOF)
         break;

      switch (option)
      {
       case 'c':
         cl_count = atoi (optarg);
         break;

       case 'D':
         cl_decode = 1;
         break;

       case 'V':
         arca_codec->verbose ++;
         break;

       case '?':
         fprintf (stderr, "encoder [-cDV] <infile >outfile\n");
         exit (0);

       default:
         fprintf (stderr, "error: '%c' unknown option\n", option);
         exit (1);
      }
   }

   if (cl_decode)
      arca_decoder ();
   else
      arca_encoder ();

   exit (0);
}
