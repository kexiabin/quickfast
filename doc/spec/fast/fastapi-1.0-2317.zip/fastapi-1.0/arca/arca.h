// $Id: arca.h,v 1.1 2006/02/07 20:23:25 Daniel.May Exp $
//
// Copyright (c), 2005-2006, Pantor Engineering AB (http://www.pantor.com)
// Copyright (c), 2005-2006, FIX Protocol Ltd (http://www.fixprotocol.org)
// All Rights Reserved.
//
// This work is distributed under the W3C® Software License [1] in the
// hope that it will be useful, but WITHOUT ANY WARRANTY; without even the
// implied warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
//
// [1] http://www.w3.org/Consortium/Legal/2002/copyright-software-20021231

#ifndef _arca_h_
#define _arca_h_

#include "fastapi.h"
#include "common.h"

//////////////////////////////////////////////////////////////////////

#pragma pack(push,1)

typedef struct insert_order_msg
{
   u16 size;
   u8  type;
   u8  pad1;

   u32 time;
   u32 seqno;
   u32 order_ref;

   u32 shares;
   i32 price;
   u8  scale;

   u8  exch_code;
   u8  sys_code;
   u8  buy_sell;
   u8  stock [8];
   u8  quote_id [5];
   u8  pad2 [3];
}
insert_order_msg;

typedef struct modify_order_msg
{
   u16 size;
   u8  type;
   u8  pad1;

   u32 time;
   u32 seqno;
   u32 order_ref;

   u32 shares;
   u32 price;
   u8  scale;

   u8  exch_code;
   u8  sys_code;
   u8  buy_sell;
   u8  stock [8];
   u8  quote_id [5];
   u8  pad2 [3];
}
modify_order_msg;

typedef struct delete_order_msg
{
   u16 size;
   u8  type;
   u8  pad1;

   u32 time;
   u32 seqno;
   u32 order_ref;

   u8  exch_code;
   u8  sys_code;
   u8  buy_sell;
   u8  stock [8];
   u8  quote_id [5];
}
delete_order_msg;

typedef struct imbalance_msg
{
   u16 size;
   u8  type;
   u8  pad1;

   u32 time;
   u32 seqno;
   u32 shares;

   i32 total_imbal;
   i32 market_imbal;

   i32 price;
   u8  scale;

   u8  exch_code;
   u8  sys_code;
   u8  auction_type;

   u8  stock [8];
   u32 auction_time;
}
imbalance_msg;

#pragma pack(pop)

//////////////////////////////////////////////////////////////////////

enum arca_tids
{
   ARCA_BASE_TID = 0,
};

enum arca_common_fields
{
   // 0-6
   MSG_MAP      = MAKE_TAG (FAST_TYPE_NULL, FAST_OP_NONE,  ARCA_BASE_TID,  0),
   MSG_TYPE     = MAKE_TAG (FAST_TYPE_U32,  FAST_OP_COPY,  ARCA_BASE_TID,  1),
   TSP_SECS     = MAKE_TAG (FAST_TYPE_U32,  FAST_OP_COPY,  ARCA_BASE_TID,  2),
   TSP_MSECS    = MAKE_TAG (FAST_TYPE_U32,  FAST_OP_NONE,  ARCA_BASE_TID,  3),
   SEQNO        = MAKE_TAG (FAST_TYPE_U32,  FAST_OP_INCR,  ARCA_BASE_TID,  4),
   ORDER_REF    = MAKE_TAG (FAST_TYPE_U32,  FAST_OP_INCR,  ARCA_BASE_TID,  5),
   SHARES       = MAKE_TAG (FAST_TYPE_U32,  FAST_OP_COPY,  ARCA_BASE_TID,  6),

   // 7-13
   PRICE        = MAKE_TAG (FAST_TYPE_U32,  FAST_OP_COPY,  ARCA_BASE_TID,  7),
   SCALE        = MAKE_TAG (FAST_TYPE_U32,  FAST_OP_COPY,  ARCA_BASE_TID,  8),
   EXCH_CODE    = MAKE_TAG (FAST_TYPE_U32,  FAST_OP_COPY,  ARCA_BASE_TID,  9),
   SYS_CODE     = MAKE_TAG (FAST_TYPE_U32,  FAST_OP_COPY,  ARCA_BASE_TID, 10),
   BUY_SELL     = MAKE_TAG (FAST_TYPE_U32,  FAST_OP_COPY,  ARCA_BASE_TID, 11),
   STOCK        = MAKE_TAG (FAST_TYPE_STR,  FAST_OP_COPY,  ARCA_BASE_TID, 12),
   QUOTE_ID     = MAKE_TAG (FAST_TYPE_STR,  FAST_OP_COPY,  ARCA_BASE_TID, 13),

   // 14-
   MARKET_IMBAL = MAKE_TAG (FAST_TYPE_U32,  FAST_OP_COPY,  ARCA_BASE_TID, 14),
   TOTAL_IMBAL  = MAKE_TAG (FAST_TYPE_U32,  FAST_OP_COPY,  ARCA_BASE_TID, 15),
   AUCT_TYPE    = MAKE_TAG (FAST_TYPE_U32,  FAST_OP_COPY,  ARCA_BASE_TID, 16),
   AUCT_TIME    = MAKE_TAG (FAST_TYPE_U32,  FAST_OP_COPY,  ARCA_BASE_TID, 17),
};

#endif // _arca_h_
