// $Id: common.c,v 1.2 2006/02/09 19:14:24 Daniel.May Exp $
//
// FIX Adapted for STreaming (sm) (FAST Protocol (sm)) 
//
// Copyright (c) 2005-2006, Pantor Engineering AB (http://www.pantor.com)
// Copyright (c) 2005-2006, SpryWare LLC (http://www.spryware.com)
// Copyright (c) 2005-2006, FIX Protocol Ltd (http://www.fixprotocol.org)
// All Rights Reserved.
//
// This work is distributed under the W3C® Software License [1] in the
// hope that it will be useful, but WITHOUT ANY WARRANTY; without even the
// implied warranty of MERCHANTABILITY, SATISFACTORY QUALITY or FITNESS 
// FOR A PARTICULAR PURPOSE.
//
// [1] http://www.w3.org/Consortium/Legal/2002/copyright-software-20021231
// [FPL's Intellectual Property details] http://www.fixprotocol.org/ip
// [FAST Protocol details] http://www.fixprotocol.org/fast
// [FAST Protocol credits] http://fixprotocol.org/fastcredits

#include "common.h"

void init_platform_io (void)
{
#ifdef WIN32
   _setmode (_fileno(stdin),O_BINARY);
   _setmode (_fileno(stdout),O_BINARY);
#endif
}

#ifdef WIN32
size_t strnlen (const char *str, size_t len)
{
   size_t p1;

   for (p1 = 0 ; p1 < len ; p1 ++)
      if (str [p1] == '\0')
         break;

   return p1;
}
#endif // defined (WIN32)

//////////////////////////////////////////////////////////////////////

int read_n (int fd, void* data, int size)
{
   char* curr = data;
   int left = size;

   while (left > 0)
   {
      int temp = read (fd, curr, left);

      if (temp <= 0)
         return -1;

      curr += temp;
      left -= temp;
   }
   return 0;
}

int write_n (int fd, const void* data, int size)
{
   const char* curr = data;
   int left = size;

   while (left > 0)
   {
      int temp = write (fd, curr, left);

      if (temp < 0)
      {
         perror ("write_n");
         exit (1);
      }
      curr += temp;
      left -= temp;
   }

   return size;
}
