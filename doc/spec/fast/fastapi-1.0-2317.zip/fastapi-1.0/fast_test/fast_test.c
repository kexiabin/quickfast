// $Id: fast_test.c,v 1.2 2006/02/09 19:18:06 Daniel.May Exp $
//
// FIX Adapted for STreaming (sm) (FAST Protocol (sm)) 
//
// Copyright (c) 2005-2006, Pantor Engineering AB (http://www.pantor.com)
// Copyright (c) 2005-2006, SpryWare LLC (http://www.spryware.com)
// Copyright (c) 2005-2006, FIX Protocol Ltd (http://www.fixprotocol.org)
// All Rights Reserved.
//
// This work is distributed under the W3C� Software License [1] in the
// hope that it will be useful, but WITHOUT ANY WARRANTY; without even the
// implied warranty of MERCHANTABILITY, SATISFACTORY QUALITY or FITNESS 
// FOR A PARTICULAR PURPOSE.
//
// [1] http://www.w3.org/Consortium/Legal/2002/copyright-software-20021231
// [FPL's Intellectual Property details] http://www.fixprotocol.org/ip
// [FAST Protocol details] http://www.fixprotocol.org/fast
// [FAST Protocol credits] http://fixprotocol.org/fastcredits
//
//
// The fast_test utility is a unit testing facility to assist in verifying a fast implementation on different
// target platforms.  It performs a variety of tests on the core fastapi functions.
//

/**
 * @example fast_test.c
 * FIX Adapted for STreaming API unit test harness
 */

#include <signal.h>
#include <setjmp.h>

#include "fastapi.h"

static fast_codec_t* decoder = NULL;
static fast_codec_t* encoder = NULL;

static int curr_id   = 0;
static int curr_mode = 0;
static int curr_code = 0;

static const char* curr_text = NULL;

static int execed_count = 0;
static int failed_count = 0;
static int passed_count = 0;

#define MAKE_I32_TAG(o,t,s) MAKE_TAG (FAST_TYPE_I32, o, t, s)
#define MAKE_STR_TAG(o,t,s) MAKE_TAG (FAST_TYPE_STR, o, t, s)
#define MAKE_U32_TAG(o,t,s) MAKE_TAG (FAST_TYPE_U32, o, t, s)

//////////////////////////////////////////////////////////////////////

static void cleanup (void)
{
   if (decoder != NULL && decoder->magic == FAST_CODEC_MAGIC)
   {
      fast_destroy_codec (decoder);
      decoder = NULL;
   }

   if (encoder != NULL && encoder->magic == FAST_CODEC_MAGIC)
   {
      fast_destroy_codec (encoder);
      encoder = NULL;
   }
}

static void started (void)
{
   fprintf (stderr, "%04d [started] '%s'\n", curr_id, curr_text);

   execed_count ++;
}

static int failed (void)
{
   fprintf (stderr, "%04d [failed]\n\n", curr_id);
   cleanup ();

   failed_count ++;
   return 0;
}

static int passed (void)
{
   fprintf (stderr, "%04d [passed]\n\n", curr_id);
   cleanup ();

   passed_count ++;
   return 0;
}

#define FAIL 0
#define PASS 1

typedef int (*test_fn) (void);

static void execute (int id, int mode, test_fn fn, const char* text)
{
   curr_id   = id;
   curr_text = text;
   curr_mode = mode;
   curr_code = 0;

   started ();
   (void) (fn () == 0 ? passed () : failed ());
}

static int expect (fast_codec_t* codec, fast_error_t error_code, int code)
{
   if (codec == NULL || codec->magic != FAST_CODEC_MAGIC)
   {
      if (code == 0)
      {
         fprintf (stderr, "     unexpected: NULL codec undetected\n");
         return -1;
      }
      else if (error_code == FAST_ERR_CODEC)
      {
         fprintf (stderr, "     expected: NULL codec\n");
         return 0;
      }
      else
      {
         fprintf (stderr, "     unexpected: NULL codec\n");
         return -1;
      }
   }

   if (error_code != FAST_ERR_NONE)
   {
      if (code == 0)
      {
         fprintf (stderr, "     unexpected success\n");
         return -1;
      }
      else
      {
         const char* text = fast_error_string (codec);

         if (codec->error->code == error_code)
         {
            fprintf (stderr, "     expected: %s\n", text);
            return 0;
         }
         else
         {
            fprintf (stderr, "     unexpected: %s\n", text);
            return -1;
         }
      }
   }
   else if (code < 0)
   {
      fprintf (stderr, "     unexpected: %s\n",
               fast_error_string (codec));
      return -1;
   }
   return 0;
}

//////////////////////////////////////////////////////////////////////

#if 0
static void test_0001 (void) // Destroy without create
{
   //_expect (encoder, FAST_ERR_CODEC, fast_destroy_codec (encoder));
}

static void test_0002 (void) // Call fast_destroy_codec twice
{
   encoder = fast_create_codec ();

   fast_destroy_codec (encoder);
   fast_destroy_codec (encoder);
}
#endif

//////////////////////////////////////////////////////////////////////

static void insert_into_buffer (fast_buffer_t* buffer, u8* data, int size)
{
   assert (size <= buffer->end - buffer->tail);

   memcpy (buffer->head, data, size);
   buffer->tail += size;
}

static void copy_buffer (fast_buffer_t* source, fast_buffer_t* target)
{
   int size = source->tail - source->head;

   assert (size <= target->end - target->tail);

   memcpy (target->tail, source->head, size);
   target->tail += size;
}

static void dump_buffer (fast_buffer_t* b, const char* msg)
{
   fprintf (stderr, "     '%s' head=%d tail=%d used=%d\n",
            msg, b->head - b->data, b->tail - b->data,
            b->tail - b->head);
}

//////////////////////////////////////////////////////////////////////

static int encode_decode_i32_none (void)
{
   static i32 data [12] =
   {
      -65, -64, -3, -2, -1, 0, 1, 2, 3, 62, 63, 64
   };

   fast_tag_t tag = MAKE_I32_TAG (FAST_OP_NONE, 0, 0);

   i32 temp [12];

   int count = 12;
   int code;
   int p1;

   encoder = fast_create_codec ();
   decoder = fast_create_codec ();

   encoder->skip_io = 1;
   decoder->skip_io = 1;

   // Start encoding a message
   if (expect (encoder, FAST_ERR_NONE,
               fast_encode_new_msg (encoder, tag)) < 0)
      return -1;

   for (p1 = 0 ; p1 < count ; p1 ++)
   {
      code = fast_encode_i32 (encoder, tag, data [p1]);
      if (code < 0) break;
   }

   if (p1 < count)
      return expect (encoder, FAST_ERR_NONE, -1);

   // Message encoding done
   if (expect (encoder, FAST_ERR_NONE,
               fast_encode_end_msg (encoder, tag)) < 0)
      return -1;

   // Copy encoder output to decoder input
   copy_buffer (encoder->output, decoder->input);

   // Start decoding a message
   if (expect (decoder, FAST_ERR_NONE,
               fast_decode_new_msg (decoder, tag)) < 0)
      return -1;

   for (p1 = 0 ; p1 < count ; p1 ++)
   {
      code = fast_decode_i32 (decoder, tag, & temp [p1]);
      if (code < 0) break;
   }

   if (p1 < count)
      return expect (decoder, FAST_ERR_NONE, -1);

   // Message decoding done
   if (expect (decoder, FAST_ERR_NONE,
               fast_decode_end_msg (decoder, tag)) < 0)
      return -1;

   {
      int errors = 0;

      for (p1 = 0 ; p1 < count ; p1 ++)
      {
         if (data [p1] != temp [p1])
         {
            fprintf (stderr, "     unexpected: data=%d != temp=%d\n",
                     data [p1], temp [p1]);

            errors ++;
         }
      }

      if (errors > 0)
         return -1;
   }

   return 0;
}

static int encode_decode_u32_none (void)
{
   static u32 data [12] =
   {
      0, 1, 2, 3, 62, 63, 64, 127, 128, 16383, 16384, 16385
   };

   fast_tag_t tag = MAKE_U32_TAG (FAST_OP_NONE, 0, 0);

   u32 temp [12];

   int count = 12;
   int code;
   int p1;

   encoder = fast_create_codec ();
   decoder = fast_create_codec ();

   encoder->skip_io = 1;
   decoder->skip_io = 1;

   // Start encoding a message
   if (expect (encoder, FAST_ERR_NONE,
               fast_encode_new_msg (encoder, tag)) < 0)
      return -1;

   for (p1 = 0 ; p1 < count ; p1 ++)
   {
      code = fast_encode_u32 (encoder, tag, data [p1]);
      if (code < 0) break;
   }

   if (p1 < count)
      return expect (encoder, FAST_ERR_NONE, -1);

   // Message encoding done
   if (expect (encoder, FAST_ERR_NONE,
               fast_encode_end_msg (encoder, tag)) < 0)
      return -1;

   // Copy encoder output to decoder input
   copy_buffer (encoder->output, decoder->input);

   // Start decoding a message
   if (expect (decoder, FAST_ERR_NONE,
               fast_decode_new_msg (decoder, tag)) < 0)
      return -1;

   for (p1 = 0 ; p1 < count ; p1 ++)
   {
      code = fast_decode_u32 (decoder, tag, & temp [p1]);
      if (code < 0) break;
   }

   if (p1 < count)
      return expect (decoder, FAST_ERR_NONE, -1);

   // Message decoding done
   if (expect (decoder, FAST_ERR_NONE,
               fast_decode_end_msg (decoder, tag)) < 0)
      return -1;

   {
      int errors = 0;

      for (p1 = 0 ; p1 < count ; p1 ++)
      {
         if (data [p1] != temp [p1])
         {
            fprintf (stderr, "     unexpected: data=%d != temp=%d\n",
                     data [p1], temp [p1]);

            errors ++;
         }
      }

      if (errors > 0)
         return -1;
   }

   return 0;
}

//////////////////////////////////////////////////////////////////////

static int decode_i32_bad_size (void)
{
   static u8 data [7] =
   {
      0xff, 0x00, 0x00, 0x00, 0x00, 0x00, 0x80
   };

   fast_tag_t tag = MAKE_I32_TAG (FAST_OP_NONE, 0, 0);
   i32 temp;

   decoder = fast_create_codec ();
   decoder->skip_io = 1;

   insert_into_buffer (decoder->input, data, sizeof (data));

   fast_decode_new_msg (decoder, tag);

   if (expect (decoder, FAST_ERR_SIZE,
               fast_decode_i32 (decoder, tag, & temp)) < 0)
      return -1;

   return 0;
}

static int decode_i32_none_no_value (void)
{
   static u8 data [1] = { 0x80 };

   fast_tag_t tag = MAKE_I32_TAG (FAST_OP_NONE, 0, 0);
   i32 temp;

   decoder = fast_create_codec ();
   decoder->skip_io = 1;

   insert_into_buffer (decoder->input, data, sizeof (data));

   if (expect (decoder, FAST_ERR_VALUE,
               fast_decode_i32 (decoder, tag, & temp)) < 0)
      return -1;

   return 0;
}

static int decode_i32_incr_no_value (void)
{
   static u8 data [1] = { 0x80 };

   fast_tag_t tag = MAKE_I32_TAG (FAST_OP_INCR, 0, 0);
   i32 temp;

   decoder = fast_create_codec ();
   decoder->skip_io = 1;

   insert_into_buffer (decoder->input, data, sizeof (data));

   if (expect (decoder, FAST_ERR_VALUE,
               fast_decode_i32 (decoder, tag, & temp)) < 0)
      return -1;

   return 0;
}

//////////////////////////////////////////////////////////////////////

static int encode_i32_bad_slot (void)
{
   fast_tag_t tag = MAKE_TAG (FAST_TYPE_I32, FAST_OP_COPY, 0,
                              MAX_PMAP_BITS + 1);

   encoder = fast_create_codec ();

   if (expect (encoder, FAST_ERR_SIZE,
               fast_encode_i32 (encoder, tag, 0)) < 0)
      return -1;

   return 0;
}

static int encode_i32_delta_bad_op (void)
{
   fast_tag_t tag = MAKE_I32_TAG (FAST_OP_DELTA, 0, 0);

   encoder = fast_create_codec ();

   if (expect (encoder, FAST_ERR_TAG_OP,
               fast_encode_i32 (encoder, tag, 3)) < 0)
      return -1;

   return 0;
}

static int encode_i32_incr_bad_op (void)
{
   fast_tag_t tag = MAKE_I32_TAG (FAST_OP_INCR, 0, 0);

   encoder = fast_create_codec ();

   if (expect (encoder, FAST_ERR_TAG_OP,
               fast_encode_i32 (encoder, tag, 0)) < 0)
      return -1;

   return 0;
}

static int encode_i32_null_codec (void)
{
   if (expect (encoder, FAST_ERR_CODEC,
               fast_encode_i32 (NULL, 0, 0)) < 0)
      return -1;

   return 0;
}

static int encode_i32_str_tag (void)
{
   fast_tag_t tag = MAKE_TAG (FAST_TYPE_STR, FAST_OP_NONE, 0, 0);

   encoder = fast_create_codec ();

   if (expect (encoder, FAST_ERR_TAG_TYPE,
               fast_encode_i32 (encoder, tag, 0)) < 0)
      return -1;

   return 0;
}

static int encode_i32_u32_tag (void)
{
   fast_tag_t tag = MAKE_TAG (FAST_TYPE_U32, FAST_OP_NONE, 0, 0);

   encoder = fast_create_codec ();

   if (expect (encoder, FAST_ERR_TAG_TYPE,
               fast_encode_i32 (encoder, tag, 0)) < 0)
      return -1;

   return 0;
}

//////////////////////////////////////////////////////////////////////

static int encode_str_incr (void)
{
   fast_tag_t tag = MAKE_STR_TAG (FAST_OP_INCR, 0, 0);

   encoder = fast_create_codec ();

   if (expect (encoder, FAST_ERR_TAG_OP,
               fast_encode_str (encoder, tag, (u8*) "foo", 3)) < 0)
      return -1;

   return 0;
}

#if 0 // not checked in fast_encode_str
static int encode_str_oversized (void)
{
   fast_tag_t tag = MAKE_STR_TAG (FAST_OP_NONE, 0, 0);

   encoder = fast_create_codec ();

   if (expect (encoder, FAST_ERR_SIZE,
               fast_encode_str (encoder, tag, (u8*) "", 1025)) < 0)
      return -1;

   return 0;
}
#endif

static int encode_str_zero_length (void)
{
   fast_tag_t tag = MAKE_STR_TAG (FAST_OP_NONE, 0, 0);

   encoder = fast_create_codec ();

   if (expect (encoder, FAST_ERR_SIZE,
               fast_encode_str (encoder, tag, (u8*) "", 0)) < 0)
      return -1;

   return 0;
}

//////////////////////////////////////////////////////////////////////

static int encode_end_msg_only (void)
{
   encoder = fast_create_codec ();

   if (expect (encoder, FAST_ERR_CALL_SEQ,
               fast_encode_end_msg (encoder, 0)) < 0)
      return -1;

   return 0;
}

static int encode_new_msg_twice (void)
{
   encoder = fast_create_codec ();

   if (expect (encoder, FAST_ERR_NONE,
               fast_encode_new_msg (encoder, 0)) < 0)
      return -1;

   if (expect (encoder, FAST_ERR_CALL_SEQ,
               fast_encode_new_msg (encoder, 0)) < 0)
      return -1;

   return 0;
}

static int encode_msg_buffer_overflow (void)
{
   fast_tag_t tag = MAKE_I32_TAG (FAST_OP_NONE, 0, 0);

   int code;
   int p1;

   encoder = fast_create_codec ();

   for (p1 = 0 ; p1 < 10000 ; p1 ++)
   {
      code = fast_encode_i32 (encoder, tag, p1);

      if (code < 0)
         break;
   }

   if (expect (encoder, FAST_ERR_SIZE, code) < 0)
      return -1;

   return 0;
}

static int encode_output_buffer_overflow (void)
{
   fast_tag_t tag = MAKE_I32_TAG (FAST_OP_NONE, 0, 0);

   int code;
   int p1;

   encoder = fast_create_codec ();

   encoder->skip_io = 1;

   for (p1 = 0 ; p1 < 10000 ; p1 ++)
   {
      code = fast_encode_new_msg (encoder, tag);

      if (code < 0)
         break;

      code = fast_encode_i32 (encoder, tag, p1);

      if (code < 0)
         break;

      code = fast_encode_end_msg (encoder, tag);

      if (code < 0)
         break;
   }

   if (expect (encoder, FAST_ERR_SIZE, code) < 0)
      return -1;

   return 0;
}

//////////////////////////////////////////////////////////////////////

#define ENTRY(result, name) { result, name, #name }

typedef struct test_entry
{
   int result;
   test_fn fn;
   const char* name;
}
test_entry;

static test_entry test_array [] =
{
   ENTRY (FAIL, decode_i32_bad_size),
   ENTRY (FAIL, decode_i32_none_no_value),
   ENTRY (FAIL, decode_i32_incr_no_value),

   ENTRY (FAIL, encode_i32_bad_slot),
   ENTRY (FAIL, encode_i32_delta_bad_op),
   ENTRY (FAIL, encode_i32_incr_bad_op),
   ENTRY (FAIL, encode_i32_null_codec),
   ENTRY (FAIL, encode_i32_str_tag),
   ENTRY (FAIL, encode_i32_u32_tag),

   ENTRY (FAIL, encode_str_incr),
   //_ENTRY (FAIL, encode_str_oversized),
   ENTRY (FAIL, encode_str_zero_length),

   ENTRY (FAIL, encode_end_msg_only),
   ENTRY (FAIL, encode_new_msg_twice),
   ENTRY (FAIL, encode_msg_buffer_overflow),
   ENTRY (FAIL, encode_output_buffer_overflow),

   ENTRY (PASS, encode_decode_i32_none),
   ENTRY (PASS, encode_decode_u32_none),

   { 0, NULL },
};

int main (int argc, char* argv [])
{
   int p1;

   for (p1 = 0 ; test_array [p1].fn != NULL ; p1 ++)
   {
      test_entry* entry = & test_array [p1];

      execute (p1, entry->result, entry->fn, entry->name);
   }

   fprintf (stderr, "== all tests done, %s passed.\n",
            passed_count == execed_count ? "ALL" : "NOT all");
   fprintf (stderr, "== executed %8d\n", execed_count);
   fprintf (stderr, "== passed   %8d\n", passed_count);
   fprintf (stderr, "== failed   %8d\n", failed_count);

   return 0;
}
