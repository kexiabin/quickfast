#!/bin/sh

./encode/encode <example.dat >example.fast
./decode/decode <example.fast >example.dat2
diff -s example.dat example.dat2
