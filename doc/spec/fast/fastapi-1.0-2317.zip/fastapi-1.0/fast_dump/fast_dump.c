// $Id: fast_dump.c,v 1.2 2006/02/09 19:18:06 Daniel.May Exp $
//
// FIX Adapted for STreaming (sm) (FAST Protocol (sm)) 
//
// Copyright (c) 2005-2006, Pantor Engineering AB (http://www.pantor.com)
// Copyright (c) 2005-2006, SpryWare LLC (http://www.spryware.com)
// Copyright (c) 2005-2006, FIX Protocol Ltd (http://www.fixprotocol.org)
// All Rights Reserved.
//
// This work is distributed under the W3C� Software License [1] in the
// hope that it will be useful, but WITHOUT ANY WARRANTY; without even the
// implied warranty of MERCHANTABILITY, SATISFACTORY QUALITY or FITNESS 
// FOR A PARTICULAR PURPOSE.
//
// [1] http://www.w3.org/Consortium/Legal/2002/copyright-software-20021231
// [FPL's Intellectual Property details] http://www.fixprotocol.org/ip
// [FAST Protocol details] http://www.fixprotocol.org/fast
// [FAST Protocol credits] http://fixprotocol.org/fastcredits
//

//
// The fast_dump utility will dump a fast data stream to stdout.  This utility is useful for debuging fast output
//

/**
 * @example fast_dump.c
 * FIX Adapted for STreaming API dump utility
 */

#include "common.h"
#include "fastapi.h"

//////////////////////////////////////////////////////////////////////

static u32 field_array [128];


static u32 count_bits (u8* data, int size)
{
   u32 count = 0;
   int p1, p2;

   assert (size > 0);
   memset (field_array, 0, sizeof (field_array));

   for (p1 = 0 ; p1 < size ; p1 ++)
   {
      for (p2 = 0 ; p2 < 7 ; p2 ++)
      {
         if ((data [p1] & (0x40 >> p2)) != 0)
         {
            field_array [count ++] = p1 * 7 + p2;
         }
      }
   }
   return count;
}

static u32 decode_u32 (u8* data, int size)
{
   u32 temp = 0;
   int p1;

   assert (size > 0);

   for (p1 = 0 ; p1 < size ; p1 ++)
   {
      temp = (temp << 7) | data [p1];
   }
   return temp;
}

//////////////////////////////////////////////////////////////////////

static void dump_hex (u8* data, u32 size,FILE *out)
{
   u32 p1;

   assert (size > 0);

   for (p1 = 0 ; p1 < size ; p1 ++)
      fprintf (out, " %02x", data [p1]);

   /* print last byte again, with high bit set */
   fprintf (out, " (%02x)", data [p1-1] | 0x80);
   fprintf (out, "%*s |", 20 - 3 * size - 5, "");
}

static void dump_pmap (u8* data, u32 size, u32 count, FILE *out)
{
   dump_hex (data, size,out);
   fprintf (out, " -- [PMAP %u fields]\n", count);
}

static void dump_data (u32 offset, u8* data, u32 size, int printable, FILE *out)
{
   u32 temp = decode_u32 (data, size);

   dump_hex (data, size,out);

   fprintf (out, " %2u", field_array [offset]);

   if (printable)
   {
      fprintf (out, " '%.*s'", size, data);
      fprintf (out, "%*s", 10 - size, "");

      if (size < 5)
         fprintf (out, " %u", temp);
   }
   else
   {
      fprintf (out, "              ");
      fprintf (out, "%u", temp);
   }
   fprintf (out, "\n");
}

//////////////////////////////////////////////////////////////////////

static void dump_stream (FILE *in, FILE *out)
{
   u32 stream_offset = 0;
   u32 field_offset  = 0;
   u32 msg_offset = 0;

   for (;;)
   {
      u8  data [128];
      u32 size = 0;
      u32 printable = 1;
      u32 count = 0;

      for (;;)
      {
         int chr = getc (in);

         if (chr == EOF)
            goto eof_label;

         stream_offset ++;

         data [size ++] = chr & 0x7f;

         printable = printable && isprint (chr & 0x7f);

         if (chr >= 0x80)
         {
            if (count == 0)
            {
               msg_offset ++;

               fprintf (out, "--------------+");
               fprintf (out, "---------------------+");
               fprintf (out, "-----------------\n");

               fprintf (out, "%8u %4u |",
                        stream_offset - size, msg_offset);

               count = count_bits (data, size);
               dump_pmap (data, size, count,out);

               field_offset = 0;
            }
            else
            {
               fprintf (out, "%8u      |", stream_offset - size);
               dump_data (field_offset ++, data, size, printable,out);
            }

            if (field_offset >= count)
               break;

            printable = 1;
            size = 0;
         }
      }
   }
  eof_label:
   fprintf (out, "\n");
   return;
}

//////////////////////////////////////////////////////////////////////

int main (int argc, char* argv [])
{
   FILE  *in,*out;
   init_platform_io ();

   in  = stdin;
   out = stdout;

   for (;;)
   {
	   int option = getopt (argc, argv, "?");

      if (option == EOF)
         break;

      switch (option)
      {
       case '?':
         fprintf (stderr, "usage: fast_dump <infile>\n");
         break;

       default:
         fprintf (stderr, "error: unknown switch '%c'\n", option);
         exit (1);
      }
   }

   dump_stream (in,out);
   exit (0);
}
