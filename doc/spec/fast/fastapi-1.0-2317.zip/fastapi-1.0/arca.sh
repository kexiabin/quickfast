#!/bin/sh

source=arca.dat

./arca/arca -V <$source >arca.fast
./arca/arca -V -D <arca.fast >arca2.dat

diff -q $source arca2.dat
