// $Id: decode.c,v 1.2 2006/02/09 19:14:25 Daniel.May Exp $
//
// FIX Adapted for STreaming (sm) (FAST Protocol (sm)) 
//
// Copyright (c) 2005-2006, Pantor Engineering AB (http://www.pantor.com)
// Copyright (c) 2005-2006, SpryWare LLC (http://www.spryware.com)
// Copyright (c) 2005-2006, FIX Protocol Ltd (http://www.fixprotocol.org)
// All Rights Reserved.
//
// This work is distributed under the W3C� Software License [1] in the
// hope that it will be useful, but WITHOUT ANY WARRANTY; without even the
// implied warranty of MERCHANTABILITY, SATISFACTORY QUALITY or FITNESS 
// FOR A PARTICULAR PURPOSE.
//
// [1] http://www.w3.org/Consortium/Legal/2002/copyright-software-20021231
// [FPL's Intellectual Property details] http://www.fixprotocol.org/ip
// [FAST Protocol details] http://www.fixprotocol.org/fast
// [FAST Protocol credits] http://fixprotocol.org/fastcredits
//
// The example application 'decode' will decode a sample data feed from the FAST format back to it's original
// format.  The FAST data is read from stdin and decoded into original messages.  Ouptut is written to stdout.  
// See the sample test scripts example.sh (Linux) or example.bat (Windows) for example usage.
//

/**
 * @example decode.c
 * FIX Adapted for STreaming API encoder example
 */

#include "fastapi.h"
#include "common.h"

// define the template ID
enum test_tids
{
   TEST_BASE_TID = 0,
};

// define the fields
enum test_fields
{
   TID          = MAKE_TAG (FAST_TYPE_U32,  FAST_OP_COPY,  TEST_BASE_TID,  0),
   SEQ_NUM      = MAKE_TAG (FAST_TYPE_U32,  FAST_OP_INCR,  TEST_BASE_TID,  1),
   TIME         = MAKE_TAG (FAST_TYPE_U32,  FAST_OP_COPY,  TEST_BASE_TID,  2),
   SYMBOL       = MAKE_TAG (FAST_TYPE_STR,  FAST_OP_COPY,  TEST_BASE_TID,  3),
   PRICE        = MAKE_TAG (FAST_TYPE_U32,  FAST_OP_COPY,  TEST_BASE_TID,  4),
   SHARES       = MAKE_TAG (FAST_TYPE_U32,  FAST_OP_COPY,  TEST_BASE_TID,  5),
   EXCH         = MAKE_TAG (FAST_TYPE_STR,  FAST_OP_COPY,  TEST_BASE_TID,  6),
};



int main(int argc, char* argv[])
{
   fast_codec_t *codec;
   u32 tid,seq_num,price,time,shares;
   char symbol[16],exch[2];

	// We want binary input from stdio and stdout 
    init_platform_io();

   // Create the Codec
	codec = fast_create_codec ();
	assert(NULL!=codec);

	// Decode the data
	fprintf(stdout,"; SeqNum, Time, Symbol,Price, Shares, Exch\r\n");

    // keep decoding while data is present
	while(fast_decode_new_msg (codec, TID) > 0)
	{
		fast_decode_u32 (codec, TID, &tid);
		assert(tid==1);
		// SeqNum is first 6 chars in input file, starting at pos 0
		fast_decode_u32 (codec, SEQ_NUM, &seq_num);				
		// Time is next 6 chars in input file, starting at pos 7
		fast_decode_u32 (codec, TIME, &time);				
		// Symbol is next 3 chars in input file, starting at pos 14
		fast_decode_str (codec, SYMBOL, symbol, 3);				
		// Price is next 5 chars in input file, starting at pos 18
		fast_decode_u32 (codec, PRICE, &price);				
		// Shares are next 3 chars in input file, starting at pos 24
		fast_decode_u32 (codec, SHARES, &shares);				
		// Exchange is next char in input file, starting at pos 28
		fast_decode_str (codec, EXCH, exch,1);
		// we are done with this message
		if(fast_decode_end_msg (codec,0) != FAST_ERR_NONE)
			fast_print_error (codec, stderr);
		else
			fprintf(stdout,"%06d %06d %-3.3s %05d %03d %c\r\n",seq_num,time,symbol,price,shares,exch[0]);
	}

	// clean up
	fast_destroy_codec (codec);
	return 0;
}
