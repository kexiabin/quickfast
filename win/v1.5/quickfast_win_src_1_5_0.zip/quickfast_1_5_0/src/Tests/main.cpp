// Copyright (c) 2009, Object Computing, Inc.
// All rights reserved.
// See the file license.txt for licensing information.
#include <Common/QuickFASTPch.h>
#define BOOST_TEST_MODULE QuickFASTTest
#include <boost/test/unit_test.hpp>

