// Copyright (c) 2009, Object Computing, Inc.
// All rights reserved.
// See the file license.txt for licensing information.
#include <Examples/ExamplesPch.h>
#include "ConsoleLock.h"
using namespace QuickFAST;
using namespace Examples;

boost::mutex ConsoleLock::consoleMutex;
