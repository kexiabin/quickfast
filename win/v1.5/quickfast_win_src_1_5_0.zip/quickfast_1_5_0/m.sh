$MPC_ROOT/mwc.pl -type make QuickFAST.mwc
