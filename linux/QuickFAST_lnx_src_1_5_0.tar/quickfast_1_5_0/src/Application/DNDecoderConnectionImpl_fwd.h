// Copyright (c) 2009, 2010, 2011 Object Computing, Inc.
// All rights reserved.
// See the file license.txt for licensing information.
#ifdef _MSC_VER
# pragma once
#endif
#ifndef DNDECODERCONNECTIONIMPL_FWD_H
#define DNDECODERCONNECTIONIMPL_FWD_H
namespace QuickFAST
{
  namespace DotNet
  {
    class DNDecoderConnectionImpl;
  }
}
#endif // DNDECODERCONNECTION_IMPL_FWD_H
